"""
FastAPI Backend for Disaster Management System
Main API server running on localhost:8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Optional
import logging
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from backend.agents.orchestrator import AgentOrchestrator
from backend.models.ml_model import MLModelManager
from rag.vector_store import RetrievalAugmentedGenerationEngine
from rag.documents.disaster_sops import get_disaster_sops

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Disaster Management & Public Safety Advisory System",
    description="AI-powered intelligent disaster management with multi-agent orchestration",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize system components
rag_engine = RetrievalAugmentedGenerationEngine()
orchestrator = AgentOrchestrator(rag_engine=rag_engine)

# Setup knowledge base on startup
@app.on_event("startup")
def startup_event():
    """Initialize RAG knowledge base on startup"""
    logger.info("Initializing RAG knowledge base...")
    
    documents = {
        "disaster_standard_operating_procedures": get_disaster_sops()
    }
    
    orchestrator.setup_knowledge_base(documents)
    logger.info("RAG knowledge base initialized successfully")


# Pydantic Models
class DisasterQuery(BaseModel):
    """Represents a disaster query request"""
    query_text: str
    location: Optional[str] = None
    severity_estimate: Optional[str] = None


class DisasterQueryResponse(BaseModel):
    """Response model for disaster queries"""
    query_id: str
    success: bool
    disaster_classification: Dict
    risk_assessment: Dict
    guidance: Dict
    final_advisory: str
    confidence_score: float
    warnings: List[str]
    execution_time_ms: float


class HealthResponse(BaseModel):
    """System health status"""
    status: str
    uptime_seconds: float
    queries_processed: int
    system_health: Dict


# API Routes
@app.get("/", tags=["Health"])
def root():
    """Root endpoint - API information"""
    return {
        "name": "Disaster Management & Public Safety Advisory System",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "health": "/health",
            "analyze_disaster": "/api/v1/analyze",
            "ml_model_info": "/api/v1/models",
            "system_status": "/api/v1/system/status",
        },
        "documentation": "/docs",
    }


@app.get("/health", tags=["Health"])
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Disaster Management System",
        "orchestrator_ready": True,
        "rag_ready": True,
    }


@app.post("/api/v1/analyze", response_model=Dict, tags=["Disaster Analysis"])
def analyze_disaster(query: DisasterQuery):
    """
    Analyze disaster query through multi-agent system.
    
    This endpoint:
    1. Accepts a disaster-related query
    2. Routes through intent classification
    3. Retrieves relevant SOPs via RAG
    4. Assesses risk levels
    5. Generates verified guidance
    6. Returns comprehensive advisory
    
    Args:
        query: DisasterQuery with query_text and optional context
        
    Returns:
        Comprehensive disaster analysis with guidance
    """
    try:
        logger.info(f"Processing disaster query: {query.query_text[:100]}...")
        
        # Process through orchestrator
        result = orchestrator.process_query(
            query_text=query.query_text,
            source="api"
        )
        
        # Format response
        response = {
            "query_id": result.query_id,
            "success": result.success,
            "disaster_classification": result.disaster_classification,
            "risk_assessment": result.risk_assessment,
            "guidance": {
                "immediate_actions": result.guidance.get("immediate_actions", []),
                "evacuation_procedures": result.guidance.get("evacuation_procedures", []),
                "safety_instructions": result.guidance.get("safety_instructions", []),
                "resources": result.guidance.get("resources", []),
                "emergency_contacts": result.guidance.get("contacts", []),
            },
            "verification": result.verification,
            "safety_check": result.safety_check,
            "final_advisory": result.final_advisory,
            "confidence_score": round(result.confidence_score, 3),
            "execution_time_ms": round(result.execution_time_ms, 2),
            "warnings": result.warnings,
            "execution_logs": [
                {
                    "agent": log.agent_name,
                    "state": log.state.value,
                    "duration_ms": round(log.duration_ms, 2),
                    "timestamp": log.timestamp,
                    "error": log.error
                }
                for log in result.execution_logs
            ]
        }
        
        logger.info(f"Query {result.query_id} processed successfully")
        return response
        
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/models", tags=["System Information"])
def get_model_info():
    """Get information about ML models"""
    return {
        "models": {
            "intent_classification": {
                "type": "Rule-based NLP Classifier",
                "function": "Classifies disaster type and urgency level",
                "supported_disasters": [
                    "earthquake", "flood", "wildfire", "hurricane", "tornado",
                    "tsunami", "landslide", "severe_storm", "chemical_spill",
                    "nuclear_incident", "pandemic"
                ],
                "urgency_levels": ["LOW", "MODERATE", "HIGH", "CRITICAL"],
            },
            "risk_assessment": {
                "type": "Multi-factor Risk Analysis",
                "function": "Predicts disaster severity and identifies vulnerable populations",
                "severity_scale": "0-100",
                "factors_considered": [
                    "intensity", "proximity", "population_exposure",
                    "infrastructure_vulnerability", "response_capacity",
                    "environmental_factors"
                ]
            },
            "rag_engine": {
                "type": "Retrieval-Augmented Generation",
                "function": "Retrieves relevant disaster SOPs using semantic search",
                "chunk_size": 500,
                "overlap": 50,
                "embedding_type": "TF-IDF similarity",
            }
        }
    }


@app.get("/api/v1/system/status", tags=["System Information"])
def system_status():
    """Get comprehensive system health and statistics"""
    health = orchestrator.get_system_health()
    
    return {
        "status": "operational",
        "timestamp": str(__import__('datetime').datetime.now().isoformat()),
        "system_metrics": {
            "queries_processed": health.get("total_queries_processed", 0),
            "successful_queries": health.get("successful_queries", 0),
            "average_confidence": health.get("average_confidence", 0),
            "average_execution_time_ms": health.get("average_execution_time_ms", 0),
        },
        "agents": {
            "orchestrator": health.get("orchestrator_state", "idle"),
        },
        "statistics": {
            "retrieval": health.get("retrieval_stats", {}),
            "safety": health.get("safety_stats", {}),
            "verification": health.get("verification_stats", {}),
        }
    }


@app.get("/api/v1/system/knowledge-base", tags=["System Information"])
def knowledge_base_info():
    """Get information about RAG knowledge base"""
    stats = rag_engine.get_retrieval_stats()
    
    return {
        "knowledge_base": {
            "status": "initialized",
            "documents": stats.get("knowledge_base_stats", {})
        },
        "retrieval_performance": {
            "queries_processed": stats.get("queries_processed", 0),
            "average_relevance_score": stats.get("avg_retrieval_score", 0),
            "max_relevance_score": stats.get("max_retrieval_score", 0),
            "min_relevance_score": stats.get("min_retrieval_score", 0),
        }
    }


@app.post("/api/v1/test/sample-queries", tags=["Testing"])
def run_sample_queries():
    """
    Run sample disaster queries for testing.
    Useful for demonstration and validation.
    """
    sample_queries = [
        "There's an earthquake happening right now with strong shaking!",
        "Severe flooding reported in low-lying areas near the river",
        "Major wildfire spreading rapidly toward residential areas",
    ]
    
    results = []
    for query_text in sample_queries:
        try:
            result = orchestrator.process_query(query_text=query_text, source="test")
            results.append({
                "query": query_text,
                "success": result.success,
                "disaster_type": result.disaster_classification.get("disaster_type"),
                "severity": result.risk_assessment.get("severity_category"),
                "confidence": round(result.confidence_score, 3),
            })
        except Exception as e:
            results.append({
                "query": query_text,
                "success": False,
                "error": str(e)
            })
    
    return {
        "test_run_completed": True,
        "sample_queries": len(sample_queries),
        "results": results
    }


@app.post("/api/v1/test/ml-model", tags=["Testing"])
def test_ml_model(query: DisasterQuery):
    """Test ML model classification without full orchestration"""
    ml_manager = MLModelManager()
    result = ml_manager.process_query(query.query_text)
    
    return {
        "query": query.query_text,
        "ml_analysis": result
    }


@app.get("/api/v1/documentation", tags=["Documentation"])
def get_documentation():
    """Get system documentation"""
    return {
        "title": "Disaster Management & Public Safety Advisory System",
        "version": "1.0.0",
        "description": "AI-powered disaster management using multi-agent architecture with RAG",
        "quick_start": {
            "1_analyze_disaster": "POST /api/v1/analyze with DisasterQuery",
            "2_view_status": "GET /api/v1/system/status",
            "3_test_models": "POST /api/v1/test/ml-model",
        },
        "key_features": [
            "Intent Classification - Identifies disaster type and urgency",
            "Risk Assessment - Predicts severity and affected populations",
            "RAG Retrieval - Fetches relevant disaster SOPs",
            "Guidance Generation - Creates actionable instructions",
            "Verification - Ensures factual accuracy",
            "Safety Checks - Prevents harmful or panicked language",
        ],
        "agents": [
            "Intent Classification Agent",
            "Risk Assessment Agent",
            "Information Retrieval Agent (RAG)",
            "Guidance Agent",
            "Verification Agent",
            "Safety Checker",
            "Agent Orchestrator",
        ]
    }


# Error handlers
@app.exception_handler(Exception)
def global_exception_handler(request, exc):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {str(exc)}")
    return {
        "success": False,
        "error": str(exc),
        "message": "An error occurred processing your request"
    }


if __name__ == "__main__":
    import uvicorn
    
    logger.info("Starting Disaster Management System API server...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
