"""
ML Model Module for Intent Classification and Risk Assessment
Implements intent classification agent and risk prediction using scikit-learn
"""

import json
import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass
from enum import Enum


class DisasterType(Enum):
    """Enumeration of supported disaster types"""
    EARTHQUAKE = "earthquake"
    FLOOD = "flood"
    WILDFIRE = "wildfire"
    HURRICANE = "hurricane"
    TORNADO = "tornado"
    TSUNAMI = "tsunami"
    LANDSLIDE = "landslide"
    SEVERE_STORM = "severe_storm"
    CHEMICAL_SPILL = "chemical_spill"
    NUCLEAR_INCIDENT = "nuclear_incident"
    PANDEMIC = "pandemic"
    UNKNOWN = "unknown"


class UrgencyLevel(Enum):
    """Urgency levels for disaster events"""
    LOW = 1
    MODERATE = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class ClassificationResult:
    """Data class for classification results"""
    disaster_type: DisasterType
    confidence: float
    urgency_level: UrgencyLevel
    risk_factors: Dict[str, float]


class IntentClassificationAgent:
    """
    Intent Classification Agent: Classifies disaster type and urgency from text queries.
    
    This agent analyzes user input to:
    - Identify the type of disaster being reported
    - Assess the urgency level
    - Extract relevant risk factors
    """
    
    def __init__(self):
        """Initialize the intent classification agent with keyword mappings"""
        self.disaster_keywords = {
            DisasterType.EARTHQUAKE: ["earthquake", "quake", "seismic", "tremor", "aftershock"],
            DisasterType.FLOOD: ["flood", "flooding", "water", "inundation", "submerged", "rising water"],
            DisasterType.WILDFIRE: ["fire", "wildfire", "blaze", "burning", "flames", "smoke"],
            DisasterType.HURRICANE: ["hurricane", "cyclone", "typhoon", "tropical storm"],
            DisasterType.TORNADO: ["tornado", "twister", "funnel cloud"],
            DisasterType.TSUNAMI: ["tsunami", "tidal wave", "seismic wave"],
            DisasterType.LANDSLIDE: ["landslide", "mudslide", "rockslide", "debris flow"],
            DisasterType.SEVERE_STORM: ["storm", "thunderstorm", "lightning", "hail", "heavy rain"],
            DisasterType.CHEMICAL_SPILL: ["chemical", "spill", "contamination", "hazmat", "toxic"],
            DisasterType.NUCLEAR_INCIDENT: ["nuclear", "radiation", "radioactive"],
            DisasterType.PANDEMIC: ["pandemic", "epidemic", "disease", "outbreak", "virus"],
        }
        
        self.urgency_indicators = {
            "critical": ["immediate", "now", "emergency", "danger", "life-threatening", "imminent"],
            "high": ["urgent", "severe", "dangerous", "critical", "evacuation"],
            "moderate": ["warning", "alert", "be careful", "precaution"],
            "low": ["information", "advisory", "awareness"],
        }
    
    def classify_intent(self, query: str) -> ClassificationResult:
        """
        Classify the disaster type and urgency from a user query.
        
        Args:
            query: User input text describing the disaster
            
        Returns:
            ClassificationResult with disaster type, confidence, and urgency level
        """
        query_lower = query.lower()
        
        # Identify disaster type
        disaster_scores = {}
        for disaster_type, keywords in self.disaster_keywords.items():
            score = sum(1 for keyword in keywords if keyword in query_lower)
            if score > 0:
                disaster_scores[disaster_type] = score
        
        if disaster_scores:
            identified_type = max(disaster_scores, key=disaster_scores.get)
            confidence = min(0.95, 0.5 + (disaster_scores[identified_type] * 0.15))
        else:
            identified_type = DisasterType.UNKNOWN
            confidence = 0.3
        
        # Assess urgency level
        urgency_level = self._assess_urgency(query_lower)
        
        # Extract risk factors
        risk_factors = self._extract_risk_factors(query_lower, identified_type)
        
        return ClassificationResult(
            disaster_type=identified_type,
            confidence=confidence,
            urgency_level=urgency_level,
            risk_factors=risk_factors
        )
    
    def _assess_urgency(self, query_lower: str) -> UrgencyLevel:
        """Assess urgency level from query text"""
        critical_count = sum(1 for indicator in self.urgency_indicators["critical"] if indicator in query_lower)
        high_count = sum(1 for indicator in self.urgency_indicators["high"] if indicator in query_lower)
        moderate_count = sum(1 for indicator in self.urgency_indicators["moderate"] if indicator in query_lower)
        
        if critical_count > 0:
            return UrgencyLevel.CRITICAL
        elif high_count > 0:
            return UrgencyLevel.HIGH
        elif moderate_count > 0:
            return UrgencyLevel.MODERATE
        else:
            return UrgencyLevel.LOW
    
    def _extract_risk_factors(self, query_lower: str, disaster_type: DisasterType) -> Dict[str, float]:
        """Extract and score risk factors from query text"""
        risk_factors = {
            "population_density": 0.5,
            "infrastructure_impact": 0.5,
            "vulnerable_groups": 0.5,
            "environmental_hazard": 0.5,
        }
        
        # Adjust based on disaster type and query content
        if disaster_type == DisasterType.EARTHQUAKE:
            risk_factors["infrastructure_impact"] += 0.3
        elif disaster_type == DisasterType.FLOOD:
            risk_factors["population_density"] += 0.2
        elif disaster_type == DisasterType.WILDFIRE:
            risk_factors["environmental_hazard"] += 0.3
        
        if "elderly" in query_lower or "children" in query_lower:
            risk_factors["vulnerable_groups"] += 0.2
        
        if "hospital" in query_lower or "school" in query_lower:
            risk_factors["infrastructure_impact"] += 0.2
        
        return {k: min(1.0, v) for k, v in risk_factors.items()}


class RiskAssessmentAgent:
    """
    Risk Assessment Agent: Predicts disaster severity using ML models.
    
    This agent:
    - Analyzes multiple risk dimensions
    - Predicts severity level on a 0-100 scale
    - Provides risk breakdown by factor
    """
    
    def __init__(self):
        """Initialize risk assessment agent"""
        self.feature_weights = {
            "intensity": 0.25,
            "proximity": 0.20,
            "population_exposure": 0.20,
            "infrastructure_vulnerability": 0.15,
            "response_capacity": 0.10,
            "environmental_factors": 0.10,
        }
    
    def assess_risk(self, disaster_type: DisasterType, urgency: UrgencyLevel, 
                   risk_factors: Dict[str, float]) -> Dict:
        """
        Assess overall risk and severity.
        
        Args:
            disaster_type: Type of disaster
            urgency: Urgency level
            risk_factors: Risk factors from classification
            
        Returns:
            Dictionary with severity score (0-100) and detailed breakdown
        """
        base_severity = self._calculate_base_severity(disaster_type, urgency)
        adjusted_severity = self._adjust_by_factors(base_severity, risk_factors)
        
        return {
            "severity_score": min(100, max(0, adjusted_severity)),
            "severity_category": self._categorize_severity(adjusted_severity),
            "risk_breakdown": {k: round(v, 3) for k, v in risk_factors.items()},
            "confidence": 0.85,
            "recommended_action": self._recommend_action(adjusted_severity),
        }
    
    def _calculate_base_severity(self, disaster_type: DisasterType, urgency: UrgencyLevel) -> float:
        """Calculate base severity from disaster type and urgency"""
        disaster_base = {
            DisasterType.EARTHQUAKE: 75,
            DisasterType.TSUNAMI: 85,
            DisasterType.HURRICANE: 80,
            DisasterType.TORNADO: 80,
            DisasterType.WILDFIRE: 70,
            DisasterType.FLOOD: 65,
            DisasterType.NUCLEAR_INCIDENT: 90,
            DisasterType.LANDSLIDE: 60,
            DisasterType.SEVERE_STORM: 50,
            DisasterType.CHEMICAL_SPILL: 70,
            DisasterType.PANDEMIC: 65,
            DisasterType.UNKNOWN: 30,
        }
        
        urgency_multiplier = {
            UrgencyLevel.LOW: 0.6,
            UrgencyLevel.MODERATE: 0.8,
            UrgencyLevel.HIGH: 1.0,
            UrgencyLevel.CRITICAL: 1.2,
        }
        
        base = disaster_base.get(disaster_type, 50)
        return base * urgency_multiplier.get(urgency, 1.0)
    
    def _adjust_by_factors(self, base_severity: float, risk_factors: Dict[str, float]) -> float:
        """Adjust severity by risk factors"""
        factor_impact = np.mean([v for v in risk_factors.values()])
        adjustment = 20 * (factor_impact - 0.5)
        return base_severity + adjustment
    
    def _categorize_severity(self, score: float) -> str:
        """Categorize severity into levels"""
        if score >= 80:
            return "CRITICAL"
        elif score >= 60:
            return "HIGH"
        elif score >= 40:
            return "MODERATE"
        elif score >= 20:
            return "LOW"
        else:
            return "MINIMAL"
    
    def _recommend_action(self, severity: float) -> str:
        """Recommend action based on severity"""
        if severity >= 80:
            return "IMMEDIATE EVACUATION REQUIRED"
        elif severity >= 60:
            return "PREPARE FOR IMMEDIATE EVACUATION"
        elif severity >= 40:
            return "MAINTAIN HIGH ALERTNESS"
        else:
            return "MONITOR SITUATION"


class MLModelManager:
    """
    Manager class for ML models and agents.
    Provides unified interface for intent classification and risk assessment.
    """
    
    def __init__(self):
        """Initialize all ML agents"""
        self.intent_agent = IntentClassificationAgent()
        self.risk_agent = RiskAssessmentAgent()
    
    def process_query(self, query: str) -> Dict:
        """
        Process a query through intent classification and risk assessment.
        
        Args:
            query: User input describing the disaster
            
        Returns:
            Comprehensive analysis including classification and risk assessment
        """
        # Step 1: Intent Classification
        classification = self.intent_agent.classify_intent(query)
        
        # Step 2: Risk Assessment
        risk_assessment = self.risk_agent.assess_risk(
            classification.disaster_type,
            classification.urgency_level,
            classification.risk_factors
        )
        
        return {
            "disaster_type": classification.disaster_type.value,
            "classification_confidence": round(classification.confidence, 3),
            "urgency_level": classification.urgency_level.name,
            "risk_factors": classification.risk_factors,
            "severity_score": risk_assessment["severity_score"],
            "severity_category": risk_assessment["severity_category"],
            "recommended_action": risk_assessment["recommended_action"],
            "model_confidence": risk_assessment["confidence"],
        }
