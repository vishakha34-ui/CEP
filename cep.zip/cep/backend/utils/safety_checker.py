"""
Safety Checker Utility
Prevents hallucinations, panic-inducing language, and unsafe advice
"""

from typing import Dict, List, Tuple
from dataclasses import dataclass


@dataclass
class SafetyCheckResult:
    """Result of safety check"""
    is_safe: bool
    risk_level: str
    violations: List[str]
    warnings: List[str]
    score: float


class SafetyChecker:
    """
    Safety Checker: Prevents hallucinations, panic-inducing language, and unsafe advice.
    
    Responsibilities:
    - Detect factual hallucinations
    - Identify panic-inducing language
    - Flag unsafe or harmful advice
    - Ensure grounding in retrieved knowledge
    - Provide safety risk assessment
    - Recommend remediation
    """
    
    def __init__(self):
        """Initialize safety checker with rules"""
        self.safety_rules = self._initialize_safety_rules()
        self.safety_checks = []
        self.safe_knowledge_base = set()
    
    def _initialize_safety_rules(self) -> Dict:
        """Initialize safety rules and constraints"""
        return {
            "absolute_prohibitions": [
                "tell people not to seek medical help",
                "discourage calling emergency services",
                "promote unverified treatments",
                "suggest ignoring official guidance",
                "promise complete safety",
                "guarantee survival outcomes",
                "recommend dangerous substances",
            ],
            "panic_indicators": [
                "everyone will die",
                "guaranteed death",
                "no escape possible",
                "inevitable disaster",
                "hopeless situation",
                "certain annihilation",
                "total destruction",
            ],
            "hallucination_indicators": [
                "invented statistics",
                "fake expert claims",
                "non-existent procedures",
                "undefined technical terms without explanation",
                "contradictory information",
                "unsourced claims presented as fact",
            ],
            "unsafe_advice_patterns": [
                "ignore professional advice",
                "delay seeking help",
                "self-administer medication",
                "attempt rescue without training",
                "enter dangerous areas",
                "defy evacuation orders",
            ],
        }
    
    def check_safety(self, text: str, retrieved_context: str, 
                    disaster_context: Dict) -> SafetyCheckResult:
        """
        Perform comprehensive safety check on generated content.
        
        Args:
            text: Generated text to check
            retrieved_context: Context retrieved from RAG
            disaster_context: Context about the disaster
            
        Returns:
            SafetyCheckResult with detailed safety assessment
        """
        violations = []
        warnings = []
        
        # Check 1: Absolute prohibitions
        prohib_violations = self._check_prohibitions(text)
        violations.extend(prohib_violations)
        
        # Check 2: Panic-inducing language
        panic_warnings = self._check_panic_language(text)
        warnings.extend(panic_warnings)
        
        # Check 3: Hallucinations
        hallucination_issues = self._detect_hallucinations(text, retrieved_context)
        if hallucination_issues:
            violations.extend(hallucination_issues)
        
        # Check 4: Unsafe advice
        unsafe_warnings = self._check_unsafe_advice(text)
        warnings.extend(unsafe_warnings)
        
        # Check 5: Grounding check
        grounding_issues = self._check_grounding(text, retrieved_context)
        if grounding_issues:
            warnings.extend(grounding_issues)
        
        # Calculate safety score
        safety_score = self._calculate_safety_score(len(violations), len(warnings))
        
        # Determine risk level
        risk_level = self._determine_risk_level(violations, safety_score)
        
        result = SafetyCheckResult(
            is_safe=len(violations) == 0,
            risk_level=risk_level,
            violations=violations,
            warnings=warnings,
            score=safety_score
        )
        
        # Track check
        self.safety_checks.append({
            "disaster_type": disaster_context.get("disaster_type", "unknown"),
            "is_safe": result.is_safe,
            "violations": len(violations),
            "warnings": len(warnings),
            "score": safety_score
        })
        
        return result
    
    def _check_prohibitions(self, text: str) -> List[str]:
        """Check for absolute prohibition violations"""
        violations = []
        text_lower = text.lower()
        
        for prohibition in self.safety_rules["absolute_prohibitions"]:
            if prohibition in text_lower:
                violations.append(f"VIOLATION: Absolute prohibition detected - '{prohibition}'")
        
        # Check for indirect prohibition violations
        if "don't call 911" in text_lower or "avoid emergency" in text_lower:
            violations.append("VIOLATION: Discouraging emergency services contact")
        
        if "ignore" in text_lower and "authority" in text_lower:
            violations.append("VIOLATION: Suggesting to ignore official authority")
        
        return violations
    
    def _check_panic_language(self, text: str) -> List[str]:
        """Check for panic-inducing language"""
        warnings = []
        text_lower = text.lower()
        
        panic_count = 0
        for indicator in self.safety_rules["panic_indicators"]:
            if indicator in text_lower:
                warnings.append(f"WARNING: Panic-inducing language detected - '{indicator}'")
                panic_count += 1
        
        # Check for excessive capitalization
        caps_ratio = sum(1 for c in text if c.isupper()) / max(len(text), 1)
        if caps_ratio > 0.3:
            warnings.append("WARNING: Excessive capitalization may cause panic")
        
        # Check for extreme language frequency
        extreme_words = ["immediately", "urgent", "critical", "danger", "emergency"]
        extreme_count = sum(text_lower.count(word) for word in extreme_words)
        if extreme_count > 15:
            warnings.append("WARNING: Excessive use of extreme language")
        
        return warnings
    
    def _detect_hallucinations(self, text: str, retrieved_context: str) -> List[str]:
        """Detect potential hallucinations"""
        issues = []
        text_lower = text.lower()
        
        # Check for unattributed specific claims
        suspicious_patterns = [
            ("research shows", "studies indicate", "proven by science"),
            ("98% of people", "all victims", "everyone affected"),
        ]
        
        for pattern in suspicious_patterns:
            for phrase in pattern:
                if phrase in text_lower and phrase not in retrieved_context.lower():
                    issues.append(f"HALLUCINATION RISK: Unverified specific claim - '{phrase}'")
        
        # Check for invented statistics
        import re
        numbers = re.findall(r'\d+%|\d+ out of \d+', text)
        if numbers:
            for number in numbers:
                if number not in retrieved_context:
                    issues.append(f"HALLUCINATION RISK: Unverified statistic - '{number}'")
        
        # Check for contradictions with context
        if "safe" in text_lower and "danger" in retrieved_context.lower():
            if "definitely safe" in text_lower:
                issues.append("HALLUCINATION RISK: Contradicts source material on safety")
        
        return issues
    
    def _check_unsafe_advice(self, text: str) -> List[str]:
        """Check for unsafe advice"""
        warnings = []
        text_lower = text.lower()
        
        for pattern in self.safety_rules["unsafe_advice_patterns"]:
            if pattern in text_lower:
                warnings.append(f"WARNING: Potentially unsafe advice pattern - '{pattern}'")
        
        # Check for rescue advice without training qualifier
        if "rescue" in text_lower and "trained" not in text_lower:
            warnings.append("WARNING: Rescue advice given without training qualification")
        
        # Check for medical advice
        medical_keywords = ["cure", "treat", "medication", "dose", "medication"]
        if any(keyword in text_lower for keyword in medical_keywords):
            if "contact doctor" not in text_lower and "seek medical" not in text_lower:
                warnings.append("WARNING: Medical-related advice without professional referral")
        
        return warnings
    
    def _check_grounding(self, text: str, context: str) -> List[str]:
        """Check if guidance is grounded in retrieved context"""
        warnings = []
        
        # Extract key procedures from text
        procedures = self._extract_procedures(text)
        context_lower = context.lower()
        
        ungrounded_procedures = []
        for proc in procedures:
            proc_lower = proc.lower()
            # Check if procedure is referenced in context
            if len(proc) > 10:  # Only check substantial procedures
                keywords = proc.split()[:3]  # First 3 words
                if not any(keyword.lower() in context_lower for keyword in keywords):
                    ungrounded_procedures.append(proc)
        
        if ungrounded_procedures:
            warnings.append(f"WARNING: Some procedures may not be grounded in retrieved context")
        
        return warnings
    
    def _extract_procedures(self, text: str) -> List[str]:
        """Extract procedures from text"""
        # Simple extraction - look for imperative statements
        sentences = text.split(".")
        procedures = [s.strip() for s in sentences if any(
            verb in s.lower() for verb in ["move", "go", "call", "contact", "do", "find"]
        ) and len(s.strip()) > 10]
        return procedures[:5]  # Return top 5
    
    def _calculate_safety_score(self, violations: int, warnings: int) -> float:
        """Calculate overall safety score (0-1)"""
        # Violations are critical (heavily penalized)
        # Warnings are important but less critical
        score = 1.0
        score -= (violations * 0.2)  # Each violation reduces by 0.2
        score -= (warnings * 0.05)   # Each warning reduces by 0.05
        
        return max(0.0, min(1.0, score))
    
    def _determine_risk_level(self, violations: List[str], score: float) -> str:
        """Determine risk level"""
        if len(violations) > 0:
            return "CRITICAL"
        elif score < 0.5:
            return "HIGH"
        elif score < 0.7:
            return "MODERATE"
        else:
            return "LOW"
    
    def sanitize_text(self, text: str) -> str:
        """Attempt to sanitize unsafe text"""
        sanitized = text
        
        # Replace panic-inducing phrases
        panic_replacements = {
            "everyone will die": "there is significant risk",
            "guaranteed death": "people may be at risk",
            "no escape": "evacuation is recommended",
            "totally destroyed": "significantly affected",
        }
        
        for panic, safe in panic_replacements.items():
            sanitized = sanitized.lower().replace(panic, safe)
        
        # Ensure emergency contact is emphasized
        if "911" not in sanitized and "emergency" in sanitized:
            sanitized += "\n\nFor emergencies, contact 911 immediately."
        
        return sanitized
    
    def get_safety_statistics(self) -> Dict:
        """Get safety check statistics"""
        if not self.safety_checks:
            return {"checks": 0}
        
        safe_count = sum(1 for c in self.safety_checks if c["is_safe"])
        
        return {
            "total_checks": len(self.safety_checks),
            "safe_content": safe_count,
            "safety_rate": round(safe_count / len(self.safety_checks), 3),
            "avg_violations": round(
                sum(c["violations"] for c in self.safety_checks) / len(self.safety_checks),
                2
            ),
            "avg_warnings": round(
                sum(c["warnings"] for c in self.safety_checks) / len(self.safety_checks),
                2
            ),
            "avg_safety_score": round(
                sum(c["score"] for c in self.safety_checks) / len(self.safety_checks),
                3
            ),
        }
