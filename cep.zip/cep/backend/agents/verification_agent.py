"""
Verification Agent
Ensures factual correctness and policy compliance of generated guidance
"""

from typing import Dict, List, Tuple
from dataclasses import dataclass


@dataclass
class VerificationResult:
    """Result of guidance verification"""
    is_verified: bool
    confidence: float
    issues_found: List[str]
    compliance_status: Dict[str, bool]
    recommendations: List[str]


class VerificationAgent:
    """
    Verification Agent: Ensures factual correctness and policy compliance.
    
    Responsibilities:
    - Verify factual accuracy of guidance
    - Check policy compliance
    - Identify inconsistencies
    - Flag potentially harmful advice
    - Provide confidence metrics
    - Suggest improvements
    """
    
    def __init__(self):
        """Initialize verification agent"""
        self.verification_rules = self._initialize_rules()
        self.verification_history = []
    
    def _initialize_rules(self) -> Dict:
        """Initialize verification rules and policies"""
        return {
            "critical_safety_phrases": [
                "turn around don't drown",
                "drop cover hold on",
                "do not use elevators",
                "evacuation",
                "assembly point",
                "emergency services"
            ],
            "forbidden_phrases": [
                "guaranteed safe",
                "no danger",
                "will not be affected",
                "completely safe",
                "panic",
                "everyone will die",
                "do not call 911"
            ],
            "required_disclosures": [
                "follow official guidance",
                "emergency responders",
                "local authorities",
                "official broadcasts",
                "999" or "911"
            ],
            "compliance_checks": [
                "includes_evacuation_procedures",
                "includes_emergency_contacts",
                "includes_safety_warnings",
                "avoids_panic_language",
                "promotes_official_channels",
                "includes_vulnerable_population_considerations"
            ]
        }
    
    def verify_guidance(self, guidance_output, guidance_context: Dict) -> VerificationResult:
        """
        Verify the accuracy and compliance of generated guidance.
        
        Args:
            guidance_output: GuidanceOutput object from guidance agent
            guidance_context: Context about the disaster and guidance
            
        Returns:
            VerificationResult with verification details
        """
        issues = []
        compliance_status = {}
        
        # Check for forbidden language
        forbidden_found = self._check_forbidden_language(guidance_output)
        if forbidden_found:
            issues.extend(forbidden_found)
        
        # Check for required safety elements
        required_found = self._check_required_elements(guidance_output)
        if not all(required_found.values()):
            issues.append("Missing required safety elements")
        
        # Check compliance with policies
        compliance_status = self._check_compliance(guidance_output, guidance_context)
        if not all(compliance_status.values()):
            issues.append(f"Policy compliance issues: {sum(1 for v in compliance_status.values() if not v)} violations")
        
        # Check for logical consistency
        consistency_issues = self._check_consistency(guidance_output, guidance_context)
        if consistency_issues:
            issues.extend(consistency_issues)
        
        # Calculate verification confidence
        confidence = self._calculate_confidence(issues, compliance_status)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(issues, guidance_context)
        
        result = VerificationResult(
            is_verified=len(issues) == 0 and all(compliance_status.values()),
            confidence=confidence,
            issues_found=issues,
            compliance_status=compliance_status,
            recommendations=recommendations
        )
        
        # Track verification
        self.verification_history.append({
            "disaster_type": guidance_context.get("disaster_type", "unknown"),
            "verified": result.is_verified,
            "issues": len(issues),
            "confidence": confidence
        })
        
        return result
    
    def _check_forbidden_language(self, guidance_output) -> List[str]:
        """Check for forbidden or dangerous language"""
        issues = []
        
        # Combine all text fields
        all_text = " ".join([
            " ".join(guidance_output.immediate_actions),
            " ".join(guidance_output.evacuation_procedures),
            " ".join(guidance_output.safety_instructions),
            " ".join(guidance_output.resource_locations),
            guidance_output.additional_notes,
        ]).lower()
        
        for phrase in self.verification_rules["forbidden_phrases"]:
            if phrase in all_text:
                issues.append(f"Forbidden phrase detected: '{phrase}'")
        
        # Check for excessive urgency that might cause panic
        urgent_count = all_text.count("urgent") + all_text.count("immediate") + all_text.count("now")
        if urgent_count > 10:
            issues.append("Excessive urgency language may cause panic")
        
        return issues
    
    def _check_required_elements(self, guidance_output) -> Dict[str, bool]:
        """Check for required safety elements"""
        all_text = " ".join([
            " ".join(guidance_output.immediate_actions),
            " ".join(guidance_output.evacuation_procedures),
            " ".join(guidance_output.safety_instructions),
            guidance_output.additional_notes,
        ]).lower()
        
        checks = {
            "has_emergency_contact": "911" in all_text or "emergency" in all_text,
            "has_evacuation_procedures": "evacuat" in all_text or "move" in all_text,
            "has_safety_instructions": len(guidance_output.safety_instructions) > 0,
            "has_follow_instructions": "follow" in all_text and "official" in all_text,
            "has_assembly_info": "assembly" in all_text or "shelter" in all_text,
        }
        
        return checks
    
    def _check_compliance(self, guidance_output, context: Dict) -> Dict[str, bool]:
        """Check policy compliance"""
        return {
            "avoids_medical_advice": "prescribe" not in " ".join([
                " ".join(guidance_output.immediate_actions),
                " ".join(guidance_output.safety_instructions)
            ]).lower(),
            "avoids_legal_claims": "liable" not in " ".join(guidance_output.safety_instructions).lower(),
            "promotes_professional_help": "medical" in " ".join(guidance_output.resource_locations).lower() or "911" in guidance_output.contact_information[0],
            "age_appropriate": "children" in context.get("populations", []) and any("child" in s.lower() for s in guidance_output.immediate_actions),
            "disaster_appropriate": len(guidance_output.immediate_actions) > 2,
            "includes_official_channels": any("official" in s.lower() or "authorities" in s.lower() for s in guidance_output.additional_notes.lower().split(".")),
        }
    
    def _check_consistency(self, guidance_output, context: Dict) -> List[str]:
        """Check logical consistency of guidance"""
        issues = []
        
        # Check if guidance severity matches context
        if context.get("severity_category") == "CRITICAL":
            if not any("immediate" in s.lower() or "urgent" in s.lower() 
                      for s in guidance_output.immediate_actions):
                issues.append("Critical severity should emphasize immediacy in actions")
        
        # Check if evacuation is mentioned for high severity
        if context.get("severity_category") in ["CRITICAL", "HIGH"]:
            all_text = " ".join(guidance_output.evacuation_procedures).lower()
            if "evacuate" not in all_text:
                issues.append("High severity disasters should include evacuation procedures")
        
        # Check if vulnerable populations are addressed
        if context.get("affected_populations"):
            all_text = " ".join(guidance_output.immediate_actions).lower()
            if not any(pop.lower() in all_text for pop in context.get("affected_populations", [])):
                issues.append("Guidance should address identified vulnerable populations")
        
        return issues
    
    def _calculate_confidence(self, issues: List[str], compliance: Dict[str, bool]) -> float:
        """Calculate confidence score for verification"""
        # Start with high confidence
        confidence = 0.95
        
        # Deduct for each issue
        confidence -= (len(issues) * 0.15)
        
        # Deduct for compliance failures
        compliance_failures = sum(1 for v in compliance.values() if not v)
        confidence -= (compliance_failures * 0.1)
        
        # Ensure confidence is in valid range
        return max(0.0, min(1.0, confidence))
    
    def _generate_recommendations(self, issues: List[str], context: Dict) -> List[str]:
        """Generate recommendations for improvement"""
        recommendations = []
        
        if not issues:
            recommendations.append("Guidance verified successfully - no changes needed")
            return recommendations
        
        for issue in issues:
            if "forbidden phrase" in issue:
                recommendations.append("Review and replace unsafe language with appropriate alternatives")
            elif "urgent" in issue.lower():
                recommendations.append("Use measured language - convey seriousness without causing panic")
            elif "vulnerable" in issue.lower():
                recommendations.append("Add specific guidance sections for identified vulnerable populations")
            elif "evacuation" in issue.lower():
                recommendations.append("Include clear evacuation procedures and assembly points")
            elif "emergency contact" in issue.lower():
                recommendations.append("Ensure emergency contact information (911) is clearly stated")
        
        if context.get("severity_category") == "CRITICAL":
            recommendations.append("Ensure all guidance emphasizes immediate action required")
        
        return recommendations
    
    def get_verification_statistics(self) -> Dict:
        """Get verification statistics"""
        if not self.verification_history:
            return {"verifications": 0}
        
        verified_count = sum(1 for v in self.verification_history if v["verified"])
        
        return {
            "total_verifications": len(self.verification_history),
            "verified_count": verified_count,
            "verification_rate": round(verified_count / len(self.verification_history), 3),
            "avg_confidence": round(
                sum(sum(1 for _ in range(int(v.get("confidence", 0.8) * 100))) 
                    for v in self.verification_history) / 
                max(len(self.verification_history), 1),
                3
            ),
            "avg_issues": round(
                sum(v["issues"] for v in self.verification_history) / max(len(self.verification_history), 1),
                2
            ),
        }
