"""
Guidance Agent
Generates evacuation and safety instructions using LLM + retrieved data
"""

from typing import Dict, List
from dataclasses import dataclass


@dataclass
class GuidanceOutput:
    """Structured guidance output"""
    immediate_actions: List[str]
    evacuation_procedures: List[str]
    safety_instructions: List[str]
    resource_locations: List[str]
    contact_information: List[str]
    additional_notes: str


class GuidanceAgent:
    """
    Guidance Agent: Generates evacuation and safety instructions.
    
    Responsibilities:
    - Generate context-aware guidance
    - Combine retrieved SOPs with disaster-specific advice
    - Provide step-by-step instructions
    - Offer alternative recommendations
    - Format guidance for clarity and accessibility
    """
    
    def __init__(self):
        """Initialize guidance agent"""
        self.guidance_templates = self._initialize_templates()
        self.generated_guidances = []
    
    def _initialize_templates(self) -> Dict:
        """Initialize guidance templates for different disaster types"""
        return {
            "earthquake": {
                "immediate": [
                    "DROP to hands and knees immediately",
                    "COVER head and neck under sturdy furniture",
                    "HOLD ON until shaking completely stops",
                    "If outside, move away from buildings and power lines",
                ],
                "evacuation": [
                    "Use stairs, never elevators",
                    "Watch for fallen debris and hazards",
                    "Move to designated assembly point",
                    "Stay away from buildings",
                ],
                "safety": [
                    "Check for gas leaks (smell, hissing)",
                    "Inspect building for structural damage",
                    "Turn off utilities if damage suspected",
                    "Be prepared for aftershocks",
                ]
            },
            "flood": {
                "immediate": [
                    "Move to higher ground immediately",
                    "Never attempt to drive through flooded roads",
                    "Shut off utilities if time permits",
                    "Bring important documents and medications",
                ],
                "evacuation": [
                    "Use designated evacuation routes only",
                    "Do not touch downed power lines",
                    "Avoid all floodwaters",
                    "Account for all family members",
                ],
                "safety": [
                    "Do not return home until cleared by authorities",
                    "Avoid contaminated water",
                    "Watch for displaced animals and debris",
                    "Document damage for insurance",
                ]
            },
            "wildfire": {
                "immediate": [
                    "Listen to local emergency broadcasts",
                    "Keep vehicle fueled and ready to leave",
                    "Have 'Go Bag' ready with essentials",
                    "Wear long sleeves and sturdy shoes",
                ],
                "evacuation": [
                    "Leave immediately when ordered - no delays",
                    "Drive slowly with headlights on",
                    "Keep windows closed, vents sealed",
                    "Head toward designated evacuation zones",
                ],
                "safety": [
                    "Do not return home until all-clear",
                    "Watch for embers and hot spots",
                    "Avoid affected areas for days after",
                    "Monitor air quality and use masks",
                ]
            },
            "hurricane": {
                "immediate": [
                    "Secure all outdoor items that could become projectiles",
                    "Fill bathtubs with water for emergencies",
                    "Stock up on non-perishable food and water",
                    "Prepare medications for extended isolation",
                ],
                "evacuation": [
                    "Evacuate immediately if ordered",
                    "Use main evacuation routes only",
                    "Move away from coastal areas",
                    "Do not stop or turn back",
                ],
                "safety": [
                    "Do not go outside during eye of storm",
                    "Stay away from windows and glass",
                    "Avoid downed power lines and debris",
                    "Use generators only outside",
                ]
            },
            "default": {
                "immediate": [
                    "Stay calm and assess the situation",
                    "Contact local emergency services if needed",
                    "Move away from immediate danger",
                    "Listen to official emergency broadcasts",
                ],
                "evacuation": [
                    "Follow designated evacuation routes",
                    "Move to designated assembly areas",
                    "Follow instructions from emergency responders",
                    "Account for all family members",
                ],
                "safety": [
                    "Do not return until authorities declare it safe",
                    "Document any injuries or damage",
                    "Seek medical attention if needed",
                    "Follow post-incident guidance from authorities",
                ]
            }
        }
    
    def generate_guidance(self, disaster_type: str, severity_category: str,
                        location: str, retrieved_context: str,
                        affected_populations: List[str]) -> GuidanceOutput:
        """
        Generate comprehensive guidance for the disaster scenario.
        
        Args:
            disaster_type: Type of disaster
            severity_category: CRITICAL/HIGH/MODERATE/LOW
            location: Geographic location description
            retrieved_context: Context retrieved from RAG
            affected_populations: List of vulnerable populations
            
        Returns:
            Structured guidance output
        """
        # Get appropriate template
        template_key = disaster_type.lower() if disaster_type.lower() in self.guidance_templates else "default"
        template = self.guidance_templates[template_key]
        
        # Generate immediate actions
        immediate = self._personalize_actions(
            template["immediate"],
            severity_category,
            affected_populations
        )
        
        # Generate evacuation procedures
        evacuation = self._generate_evacuation_procedures(
            template["evacuation"],
            severity_category,
            location
        )
        
        # Generate safety instructions
        safety = self._generate_safety_instructions(
            template["safety"],
            severity_category
        )
        
        # Generate resource information
        resources = self._generate_resource_info(location, affected_populations)
        
        # Generate contact information
        contacts = self._generate_contact_info(disaster_type)
        
        # Generate additional notes
        notes = self._generate_notes(disaster_type, severity_category, affected_populations)
        
        guidance = GuidanceOutput(
            immediate_actions=immediate,
            evacuation_procedures=evacuation,
            safety_instructions=safety,
            resource_locations=resources,
            contact_information=contacts,
            additional_notes=notes
        )
        
        # Track generated guidance
        self.generated_guidances.append({
            "disaster_type": disaster_type,
            "severity": severity_category,
            "location": location,
            "populations": len(affected_populations)
        })
        
        return guidance
    
    def _personalize_actions(self, base_actions: List[str], severity: str,
                            populations: List[str]) -> List[str]:
        """Personalize actions based on severity and vulnerable populations"""
        actions = base_actions.copy()
        
        if "critical" in severity.lower():
            actions = [f"[URGENT] {action}" for action in actions]
        
        if "elderly" in populations:
            actions.append("Assist elderly persons with mobility and evacuation")
        
        if "disabled" in populations:
            actions.append("Coordinate accessible evacuation assistance")
        
        if "children" in populations:
            actions.append("Keep children close and provide reassurance")
        
        return actions
    
    def _generate_evacuation_procedures(self, base_procedures: List[str],
                                       severity: str, location: str) -> List[str]:
        """Generate detailed evacuation procedures"""
        procedures = base_procedures.copy()
        
        if "critical" in severity.lower():
            procedures.insert(0, "BEGIN EVACUATION IMMEDIATELY - DO NOT DELAY")
        
        procedures.extend([
            f"Proceed to nearest shelter or safe location in {location} area",
            "Register with emergency services upon arrival",
            "Maintain family contact and report status",
        ])
        
        return procedures
    
    def _generate_safety_instructions(self, base_instructions: List[str],
                                     severity: str) -> List[str]:
        """Generate safety instructions"""
        instructions = base_instructions.copy()
        
        if "critical" in severity.lower():
            instructions.append("If trapped, call 911 with your location and wait for rescue")
        
        instructions.extend([
            "Do not use elevators or escalators",
            "Avoid touching unfamiliar objects or substances",
            "Follow all instructions from emergency personnel",
        ])
        
        return instructions
    
    def _generate_resource_info(self, location: str,
                               populations: List[str]) -> List[str]:
        """Generate resource location information"""
        resources = [
            f"Nearest evacuation shelter: Check local government website for {location}",
            "Medical assistance: Contact 911 for emergencies",
            "Emergency water/food: Available at official distribution centers",
            "Pet shelter: Contact animal control or Red Cross for pet accommodations",
        ]
        
        if "elderly" in populations:
            resources.append("Senior care services: Contact Adult Protective Services")
        
        if "disabled" in populations:
            resources.append("Disability services: Contact local disability office for support")
        
        if "children" in populations:
            resources.append("Child welfare services: Contact Child Protective Services if needed")
        
        return resources
    
    def _generate_contact_info(self, disaster_type: str) -> List[str]:
        """Generate emergency contact information"""
        return [
            "Emergency: 911",
            "Local Emergency Management: Check county/city website",
            "Red Cross Helpline: 1-800-733-2767",
            "FEMA Assistance: 1-800-621-3362",
            "Mental Health Crisis Line: 988 (Suicide & Crisis Lifeline)",
            "Disaster Assistance: Consult official disaster resources",
        ]
    
    def _generate_notes(self, disaster_type: str, severity: str,
                       populations: List[str]) -> str:
        """Generate additional notes and warnings"""
        notes = f"This guidance is specific to {disaster_type} with {severity} severity.\n\n"
        
        notes += "Important: This guidance is based on standard procedures. Always follow "
        notes += "instructions from local emergency management and first responders.\n\n"
        
        if "critical" in severity.lower():
            notes += "CRITICAL SITUATION: Your life may be in danger. Follow evacuation orders immediately.\n\n"
        
        if "elderly" in populations or "disabled" in populations:
            notes += "Special considerations for vulnerable populations are included above.\n\n"
        
        notes += "For the most current information, monitor local news and emergency broadcasts.\n"
        notes += "Stay calm, follow official guidance, and help neighbors in need."
        
        return notes
    
    def get_guidance_statistics(self) -> Dict:
        """Get guidance generation statistics"""
        if not self.generated_guidances:
            return {"guidances_generated": 0}
        
        return {
            "total_guidances": len(self.generated_guidances),
            "critical_guidances": sum(1 for g in self.generated_guidances if "CRITICAL" in g["severity"]),
            "avg_affected_populations": round(
                sum(g["populations"] for g in self.generated_guidances) / len(self.generated_guidances),
                2
            ),
        }
