"""
Risk Assessment Agent
Performs detailed risk analysis for disaster scenarios
"""

from typing import Dict, List
from dataclasses import dataclass


@dataclass
class RiskAnalysis:
    """Represents comprehensive risk analysis"""
    overall_risk_score: float
    severity_category: str
    risk_factors: Dict[str, float]
    affected_populations: List[str]
    infrastructure_at_risk: List[str]
    recommended_actions: List[str]
    confidence: float


class RiskAssessmentAgent:
    """
    Risk Assessment Agent: Performs detailed risk analysis.
    
    Responsibilities:
    - Analyze multiple risk dimensions
    - Identify vulnerable populations
    - Assess infrastructure impact
    - Recommend prioritized actions
    - Provide confidence metrics
    """
    
    def __init__(self):
        """Initialize risk assessment agent"""
        self.risk_analyses = []
        
        self.vulnerability_mapping = {
            "earthquake": {
                "populations": ["elderly", "disabled", "children", "homeless"],
                "infrastructure": ["hospitals", "schools", "bridges", "power_plants"],
                "high_risk_factors": ["building_age", "construction_quality", "soil_type"],
            },
            "flood": {
                "populations": ["low_income", "elderly", "disabled"],
                "infrastructure": ["water_treatment", "sewage", "roads", "utilities"],
                "high_risk_factors": ["elevation", "proximity_to_water", "drainage"],
            },
            "wildfire": {
                "populations": ["rural", "elderly", "disabled"],
                "infrastructure": ["forests", "power_lines", "homes", "roads"],
                "high_risk_factors": ["vegetation_density", "fuel_load", "wind"],
            },
            "hurricane": {
                "populations": ["coastal", "elderly", "low_income", "children"],
                "infrastructure": ["power_grid", "water_systems", "shelters", "hospitals"],
                "high_risk_factors": ["wind_speed", "storm_surge", "rainfall"],
            },
            "pandemic": {
                "populations": ["elderly", "immunocompromised", "healthcare_workers"],
                "infrastructure": ["hospitals", "testing_centers", "isolation_facilities"],
                "high_risk_factors": ["transmission_rate", "case_load", "hospital_capacity"],
            },
        }
    
    def analyze_risk(self, disaster_type: str, severity_score: float, 
                    location_data: Dict, risk_factors: Dict) -> RiskAnalysis:
        """
        Perform comprehensive risk analysis.
        
        Args:
            disaster_type: Type of disaster
            severity_score: Severity from ML model (0-100)
            location_data: Geographic and demographic data
            risk_factors: Risk factors from classification
            
        Returns:
            Comprehensive risk analysis
        """
        # Get vulnerability profile for disaster type
        vuln_profile = self.vulnerability_mapping.get(
            disaster_type.lower(),
            self.vulnerability_mapping["earthquake"]  # Default fallback
        )
        
        # Calculate overall risk
        overall_risk = self._calculate_overall_risk(
            severity_score, risk_factors, location_data
        )
        
        # Identify affected populations
        affected_populations = self._identify_vulnerable_populations(
            vuln_profile, location_data
        )
        
        # Assess infrastructure impact
        infrastructure_risk = self._assess_infrastructure_impact(
            vuln_profile, severity_score
        )
        
        # Generate prioritized actions
        actions = self._generate_risk_actions(overall_risk, affected_populations)
        
        analysis = RiskAnalysis(
            overall_risk_score=overall_risk["score"],
            severity_category=overall_risk["category"],
            risk_factors=risk_factors,
            affected_populations=affected_populations,
            infrastructure_at_risk=infrastructure_risk,
            recommended_actions=actions,
            confidence=min(0.95, 0.7 + (severity_score / 100) * 0.25)
        )
        
        # Track analysis
        self.risk_analyses.append({
            "disaster_type": disaster_type,
            "severity": severity_score,
            "overall_risk": overall_risk["score"],
            "action_count": len(actions)
        })
        
        return analysis
    
    def _calculate_overall_risk(self, severity: float, risk_factors: Dict, 
                              location_data: Dict) -> Dict:
        """Calculate overall risk score"""
        # Base risk from severity
        base_risk = severity
        
        # Adjust by factors
        factor_adjustment = sum(risk_factors.values()) / max(len(risk_factors), 1) * 20
        
        # Location adjustment
        location_adjustment = 0
        if location_data.get("population_density") == "high":
            location_adjustment += 10
        if location_data.get("infrastructure_critical") is True:
            location_adjustment += 5
        
        overall = min(100, base_risk + factor_adjustment + location_adjustment)
        
        if overall >= 80:
            category = "CRITICAL"
        elif overall >= 60:
            category = "HIGH"
        elif overall >= 40:
            category = "MODERATE"
        else:
            category = "LOW"
        
        return {"score": overall, "category": category}
    
    def _identify_vulnerable_populations(self, vuln_profile: Dict, 
                                        location_data: Dict) -> List[str]:
        """Identify vulnerable populations in affected area"""
        populations = vuln_profile.get("populations", [])
        
        # Filter by location data
        affected = []
        for pop in populations:
            if location_data.get(f"has_{pop}", False):
                affected.append(pop)
        
        # If no specific data, assume base vulnerabilities
        if not affected:
            affected = populations[:3]
        
        return affected
    
    def _assess_infrastructure_impact(self, vuln_profile: Dict, 
                                     severity: float) -> List[str]:
        """Assess infrastructure at risk"""
        infrastructure = vuln_profile.get("infrastructure", [])
        
        # Return more infrastructure items for higher severity
        count = min(len(infrastructure), max(2, int(severity / 25)))
        
        return infrastructure[:count]
    
    def _generate_risk_actions(self, risk_info: Dict, 
                              affected_populations: List[str]) -> List[str]:
        """Generate prioritized risk mitigation actions"""
        actions = []
        
        if risk_info["category"] == "CRITICAL":
            actions.extend([
                "Issue immediate evacuation orders",
                "Activate emergency operations center",
                "Deploy emergency services to high-risk areas",
                "Establish emergency shelters",
            ])
        elif risk_info["category"] == "HIGH":
            actions.extend([
                "Prepare evacuation orders",
                "Increase emergency service readiness",
                "Distribute emergency alerts",
                "Stock emergency supplies",
            ])
        elif risk_info["category"] == "MODERATE":
            actions.extend([
                "Issue warnings",
                "Prepare contingency plans",
                "Position resources",
                "Monitor situation closely",
            ])
        else:
            actions.extend([
                "Maintain awareness",
                "Continue monitoring",
                "Provide public information",
            ])
        
        # Add population-specific actions
        if "elderly" in affected_populations:
            actions.insert(1, "Arrange special assistance for elderly persons")
        if "disabled" in affected_populations:
            actions.insert(1, "Coordinate accessible evacuation support")
        if "children" in affected_populations:
            actions.insert(1, "Establish child protection and family services")
        
        return actions
    
    def get_risk_statistics(self) -> Dict:
        """Get risk assessment statistics"""
        if not self.risk_analyses:
            return {"assessments": 0}
        
        overall_risks = [r["overall_risk"] for r in self.risk_analyses]
        
        return {
            "total_assessments": len(self.risk_analyses),
            "avg_risk_score": round(sum(overall_risks) / len(overall_risks), 2),
            "max_risk_score": round(max(overall_risks), 2),
            "high_risk_count": sum(1 for r in self.risk_analyses if r["overall_risk"] >= 60),
        }
