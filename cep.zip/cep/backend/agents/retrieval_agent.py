"""
Information Retrieval Agent
Retrieves relevant disaster SOPs using RAG
"""

from typing import Dict, List
from dataclasses import dataclass


@dataclass
class RetrievedContext:
    """Represents retrieved context from RAG"""
    documents: List[Dict]
    query: str
    retrieval_score: float
    source_reliability: str


class RetrievalAgent:
    """
    Information Retrieval Agent: Retrieves relevant disaster SOPs using RAG.
    
    Responsibilities:
    - Query the vector store for relevant procedures
    - Rank retrieved documents by relevance
    - Assess source reliability and freshness
    - Return grounded context for guidance generation
    """
    
    def __init__(self, rag_engine):
        """
        Initialize retrieval agent.
        
        Args:
            rag_engine: RAG engine instance with vector store
        """
        self.rag_engine = rag_engine
        self.retrieved_contexts = []
    
    def retrieve_relevant_procedures(self, query: str, disaster_type: str, 
                                    top_k: int = 5) -> RetrievedContext:
        """
        Retrieve relevant SOPs for the disaster scenario.
        
        Args:
            query: User query or disaster description
            disaster_type: Type of disaster
            top_k: Number of relevant documents to retrieve
            
        Returns:
            RetrievedContext with relevant procedures
        """
        # Augment query with disaster type for better retrieval
        enhanced_query = f"{disaster_type} {query}"
        
        # Retrieve from RAG
        rag_result = self.rag_engine.augment_query(enhanced_query, top_k=top_k)
        
        # Assess retrieval quality
        retrieval_score = rag_result["retrieval_count"] / max(top_k, 1)
        source_reliability = self._assess_reliability(rag_result["retrieved_documents"])
        
        context = RetrievedContext(
            documents=rag_result["retrieved_documents"],
            query=query,
            retrieval_score=retrieval_score,
            source_reliability=source_reliability
        )
        
        # Track retrieval
        self.retrieved_contexts.append({
            "disaster_type": disaster_type,
            "query": query,
            "timestamp": rag_result["retrieval_count"],
            "score": retrieval_score
        })
        
        return context
    
    def _assess_reliability(self, documents: List[Dict]) -> str:
        """Assess reliability of retrieved sources"""
        if not documents:
            return "UNKNOWN"
        
        avg_score = sum(d["score"] for d in documents) / len(documents)
        
        if avg_score >= 0.7:
            return "HIGH"
        elif avg_score >= 0.4:
            return "MODERATE"
        else:
            return "LOW"
    
    def format_context_for_guidance(self, context: RetrievedContext) -> str:
        """
        Format retrieved context for use in guidance generation.
        
        Args:
            context: Retrieved context
            
        Returns:
            Formatted context string for LLM
        """
        if not context.documents:
            return "No standard procedures found for this scenario."
        
        formatted = "STANDARD OPERATING PROCEDURES:\n\n"
        for i, doc in enumerate(context.documents, 1):
            formatted += f"[Procedure {i}]\n"
            formatted += f"Source: {doc['source']}\n"
            formatted += f"Relevance: {doc['score']}\n"
            formatted += f"Content: {doc['content'][:300]}...\n\n"
        
        formatted += f"\nReliability Assessment: {context.source_reliability}\n"
        
        return formatted
    
    def get_retrieval_statistics(self) -> Dict:
        """Get retrieval statistics for monitoring"""
        if not self.retrieved_contexts:
            return {"retrievals": 0}
        
        return {
            "total_retrievals": len(self.retrieved_contexts),
            "avg_score": round(
                sum(r["score"] for r in self.retrieved_contexts) / len(self.retrieved_contexts),
                3
            ),
        }
