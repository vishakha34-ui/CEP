"""
Agent Orchestrator
Coordinates all agents, resolves conflicts, and validates outputs
"""

from typing import Dict, List, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from backend.models.ml_model import MLModelManager
from backend.agents.retrieval_agent import RetrievalAgent
from backend.agents.risk_assessment_agent import RiskAssessmentAgent
from backend.agents.guidance_agent import GuidanceAgent
from backend.agents.verification_agent import VerificationAgent
from backend.utils.safety_checker import SafetyChecker
from rag.vector_store import RetrievalAugmentedGenerationEngine


class AgentState(Enum):
    """States for agent execution"""
    IDLE = "idle"
    PROCESSING = "processing"
    VERIFIED = "verified"
    FAILED = "failed"


@dataclass
class DisasterQuery:
    """Represents a disaster query"""
    query_id: str
    query_text: str
    timestamp: str
    source: str = "user"


@dataclass
class AgentExecutionLog:
    """Log entry for agent execution"""
    agent_name: str
    state: AgentState
    duration_ms: float
    output_summary: str
    timestamp: str
    error: str = None


@dataclass
class OrchestrationResult:
    """Final result of orchestration"""
    query_id: str
    success: bool
    disaster_classification: Dict
    risk_assessment: Dict
    retrieved_context: Dict
    guidance: Dict
    verification: Dict
    safety_check: Dict
    final_advisory: str
    confidence_score: float
    execution_logs: List[AgentExecutionLog] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    execution_time_ms: float = 0.0


class AgentOrchestrator:
    """
    Agent Orchestrator: Coordinates all agents and resolves conflicts.
    
    Workflow:
    1. Accept disaster query
    2. Intent Classification (ML)
    3. Risk Assessment (ML)
    4. Information Retrieval (RAG)
    5. Guidance Generation (LLM)
    6. Verification (Policy)
    7. Safety Check (Safety)
    8. Conflict Resolution
    9. Output Validation
    10. Return Final Advisory
    """
    
    def __init__(self, rag_engine: RetrievalAugmentedGenerationEngine = None):
        """
        Initialize orchestrator with all agents.
        
        Args:
            rag_engine: RAG engine instance (optional, will be created if not provided)
        """
        # Initialize RAG engine
        if rag_engine is None:
            self.rag_engine = RetrievalAugmentedGenerationEngine()
        else:
            self.rag_engine = rag_engine
        
        # Initialize all agents
        self.ml_manager = MLModelManager()
        self.retrieval_agent = RetrievalAgent(self.rag_engine)
        self.risk_agent = RiskAssessmentAgent()
        self.guidance_agent = GuidanceAgent()
        self.verification_agent = VerificationAgent()
        self.safety_checker = SafetyChecker()
        
        # Execution history
        self.execution_history: List[OrchestrationResult] = []
        self.current_state = AgentState.IDLE
    
    def process_query(self, query_text: str, query_id: str = None,
                     source: str = "user") -> OrchestrationResult:
        """
        Process a disaster query through the agent pipeline.
        
        Args:
            query_text: User query about disaster
            query_id: Unique query identifier
            source: Source of query
            
        Returns:
            OrchestrationResult with complete analysis
        """
        import time
        
        # Initialize
        query_id = query_id or f"query_{int(time.time() * 1000)}"
        start_time = time.time()
        execution_logs = []
        warnings = []
        
        try:
            self.current_state = AgentState.PROCESSING
            
            # Step 1: Intent Classification
            intent_result = self._run_agent(
                "Intent Classification Agent",
                lambda: self.ml_manager.process_query(query_text),
                execution_logs
            )
            if not intent_result:
                raise Exception("Intent classification failed")
            
            disaster_type = intent_result["disaster_type"]
            urgency = intent_result["urgency_level"]
            severity_score = intent_result["severity_score"]
            
            # Step 2: Risk Assessment (already done in ML, but enhanced here)
            risk_result = self._run_agent(
                "Risk Assessment Agent",
                lambda: self.risk_agent.analyze_risk(
                    disaster_type,
                    intent_result["urgency_level"],
                    intent_result["risk_factors"]
                ),
                execution_logs
            )
            if not risk_result:
                raise Exception("Risk assessment failed")
            
            # Step 3: Information Retrieval
            retrieval_result = self._run_agent(
                "Retrieval Agent",
                lambda: self.retrieval_agent.retrieve_relevant_procedures(
                    query_text,
                    disaster_type
                ),
                execution_logs
            )
            if not retrieval_result:
                raise Exception("Information retrieval failed")
            
            # Step 4: Guidance Generation
            guidance_result = self._run_agent(
                "Guidance Agent",
                lambda: self.guidance_agent.generate_guidance(
                    disaster_type=disaster_type,
                    severity_category=risk_result.severity_category,
                    location="your location",
                    retrieved_context=self.retrieval_agent.format_context_for_guidance(retrieval_result),
                    affected_populations=risk_result.affected_populations
                ),
                execution_logs
            )
            if not guidance_result:
                raise Exception("Guidance generation failed")
            
            # Step 5: Verification
            verification_result = self._run_agent(
                "Verification Agent",
                lambda: self.verification_agent.verify_guidance(
                    guidance_result,
                    {
                        "disaster_type": disaster_type,
                        "severity_category": risk_result.severity_category,
                        "populations": risk_result.affected_populations,
                        "confidence": intent_result["classification_confidence"]
                    }
                ),
                execution_logs
            )
            if not verification_result:
                raise Exception("Verification failed")
            
            # Step 6: Safety Check
            guidance_text = self._format_guidance_for_safety_check(guidance_result)
            safety_result = self._run_agent(
                "Safety Checker",
                lambda: self.safety_checker.check_safety(
                    guidance_text,
                    self.retrieval_agent.format_context_for_guidance(retrieval_result),
                    {"disaster_type": disaster_type}
                ),
                execution_logs
            )
            if not safety_result:
                raise Exception("Safety check failed")
            
            # Step 7: Conflict Resolution
            conflicts = self._detect_conflicts(
                intent_result, risk_result, verification_result, safety_result
            )
            warnings.extend(conflicts)
            
            # Step 8: Output Validation
            if not self._validate_output(
                guidance_result, verification_result, safety_result
            ):
                raise Exception("Output validation failed")
            
            # Step 9: Generate Final Advisory
            final_advisory = self._generate_final_advisory(
                intent_result, risk_result, guidance_result,
                verification_result, safety_result
            )
            
            # Step 10: Calculate Confidence
            confidence = self._calculate_overall_confidence(
                intent_result, verification_result, safety_result
            )
            
            # Compile result
            execution_time_ms = (time.time() - start_time) * 1000
            
            result = OrchestrationResult(
                query_id=query_id,
                success=True,
                disaster_classification={
                    "disaster_type": disaster_type,
                    "confidence": intent_result["classification_confidence"],
                    "urgency_level": urgency,
                },
                risk_assessment={
                    "severity_score": severity_score,
                    "severity_category": risk_result.severity_category,
                    "affected_populations": risk_result.affected_populations,
                    "infrastructure_at_risk": risk_result.infrastructure_at_risk,
                },
                retrieved_context={
                    "document_count": len(retrieval_result.documents),
                    "retrieval_score": retrieval_result.retrieval_score,
                    "reliability": retrieval_result.source_reliability,
                },
                guidance={
                    "immediate_actions": guidance_result.immediate_actions,
                    "evacuation_procedures": guidance_result.evacuation_procedures,
                    "safety_instructions": guidance_result.safety_instructions,
                    "resources": guidance_result.resource_locations,
                    "contacts": guidance_result.contact_information,
                },
                verification={
                    "verified": verification_result.is_verified,
                    "confidence": verification_result.confidence,
                    "compliance_status": verification_result.compliance_status,
                    "issues": verification_result.issues_found,
                },
                safety_check={
                    "is_safe": safety_result.is_safe,
                    "risk_level": safety_result.risk_level,
                    "score": safety_result.score,
                    "violations": safety_result.violations,
                },
                final_advisory=final_advisory,
                confidence_score=confidence,
                execution_logs=execution_logs,
                warnings=warnings,
                execution_time_ms=execution_time_ms
            )
            
            self.current_state = AgentState.VERIFIED
            
        except Exception as e:
            self.current_state = AgentState.FAILED
            execution_logs.append(AgentExecutionLog(
                agent_name="Orchestrator",
                state=AgentState.FAILED,
                duration_ms=(time.time() - start_time) * 1000,
                output_summary=f"Error: {str(e)}",
                timestamp=datetime.now().isoformat(),
                error=str(e)
            ))
            
            result = OrchestrationResult(
                query_id=query_id,
                success=False,
                disaster_classification={},
                risk_assessment={},
                retrieved_context={},
                guidance={},
                verification={},
                safety_check={},
                final_advisory="An error occurred processing your query. Please try again or contact emergency services.",
                confidence_score=0.0,
                execution_logs=execution_logs,
                warnings=[str(e)],
                execution_time_ms=(time.time() - start_time) * 1000
            )
        
        # Track execution
        self.execution_history.append(result)
        
        return result
    
    def _run_agent(self, agent_name: str, agent_func, execution_logs: List) -> Any:
        """Run an agent and log execution"""
        import time
        
        try:
            start = time.time()
            result = agent_func()
            duration_ms = (time.time() - start) * 1000
            
            execution_logs.append(AgentExecutionLog(
                agent_name=agent_name,
                state=AgentState.IDLE,
                duration_ms=duration_ms,
                output_summary=f"Agent executed successfully",
                timestamp=datetime.now().isoformat()
            ))
            
            return result
        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            execution_logs.append(AgentExecutionLog(
                agent_name=agent_name,
                state=AgentState.FAILED,
                duration_ms=duration_ms,
                output_summary=f"Agent failed",
                timestamp=datetime.now().isoformat(),
                error=str(e)
            ))
            return None
    
    def _detect_conflicts(self, intent_result: Dict, risk_result,
                        verification_result, safety_result) -> List[str]:
        """Detect and report conflicts between agents"""
        conflicts = []
        
        # Check if safety issues conflict with severity
        if safety_result.risk_level == "CRITICAL":
            conflicts.append("Safety check indicates critical issues - advisory may need revision")
        
        # Check if verification failed despite high confidence
        if not verification_result.is_verified and intent_result.get("classification_confidence", 0) > 0.8:
            conflicts.append("High classification confidence but verification issues detected")
        
        # Check if guidance exceeds appropriate length for critical situations
        guidance_length = sum(len(action) for action in [
            " ".join(risk_result.recommended_actions) if hasattr(risk_result, 'recommended_actions') else ""
        ])
        if guidance_length > 5000:
            conflicts.append("Generated guidance is quite lengthy - consider summarization for critical situations")
        
        return conflicts
    
    def _validate_output(self, guidance_result, verification_result,
                        safety_result) -> bool:
        """Validate final output"""
        # Check if guidance has required sections
        if not guidance_result.immediate_actions:
            return False
        
        if not guidance_result.contact_information:
            return False
        
        # Check if safety check passed or has acceptable warnings
        if safety_result.risk_level == "CRITICAL" and len(safety_result.violations) > 0:
            return False
        
        return True
    
    def _generate_final_advisory(self, intent_result: Dict, risk_result,
                               guidance_result, verification_result,
                               safety_result) -> str:
        """Generate the final advisory text"""
        advisory = f"""
DISASTER MANAGEMENT ADVISORY
{'=' * 80}

SITUATION SUMMARY:
- Disaster Type: {intent_result.get('disaster_type', 'Unknown').upper()}
- Severity: {risk_result.severity_category if hasattr(risk_result, 'severity_category') else 'UNKNOWN'}
- Confidence: {int(intent_result.get('classification_confidence', 0) * 100)}%
- Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} UTC

IMMEDIATE ACTIONS (Priority Order):
"""
        for i, action in enumerate(guidance_result.immediate_actions[:5], 1):
            advisory += f"{i}. {action}\n"
        
        advisory += "\nEVACUATION & MOVEMENT:\n"
        for i, proc in enumerate(guidance_result.evacuation_procedures[:4], 1):
            advisory += f"{i}. {proc}\n"
        
        advisory += "\nSAFETY GUIDELINES:\n"
        for i, safety in enumerate(guidance_result.safety_instructions[:4], 1):
            advisory += f"{i}. {safety}\n"
        
        advisory += "\nEMERGENCY CONTACTS:\n"
        for contact in guidance_result.contact_information[:3]:
            advisory += f"• {contact}\n"
        
        advisory += "\nADDITIONAL INFORMATION:\n"
        advisory += guidance_result.additional_notes
        
        advisory += f"\n\n{'=' * 80}\n"
        advisory += "VERIFICATION STATUS: "
        advisory += "✓ VERIFIED" if verification_result.is_verified else "⚠ UNVERIFIED"
        advisory += f"\nSAFETY LEVEL: {safety_result.risk_level}\n"
        advisory += f"OVERALL CONFIDENCE: {int(self._calculate_overall_confidence(intent_result, verification_result, safety_result) * 100)}%\n"
        
        return advisory
    
    def _format_guidance_for_safety_check(self, guidance_result) -> str:
        """Format guidance output as string for safety check"""
        text = " ".join(guidance_result.immediate_actions) + " "
        text += " ".join(guidance_result.evacuation_procedures) + " "
        text += " ".join(guidance_result.safety_instructions) + " "
        text += guidance_result.additional_notes
        return text
    
    def _calculate_overall_confidence(self, intent_result: Dict,
                                     verification_result, safety_result) -> float:
        """Calculate overall confidence across all agents"""
        scores = [
            intent_result.get("classification_confidence", 0.5),
            verification_result.confidence,
            safety_result.score,
        ]
        return sum(scores) / len(scores)
    
    def setup_knowledge_base(self, documents: Dict[str, str]):
        """Set up RAG knowledge base"""
        self.rag_engine.setup_knowledge_base(documents)
    
    def get_system_health(self) -> Dict:
        """Get health status of orchestrator and all agents"""
        return {
            "orchestrator_state": self.current_state.value,
            "total_queries_processed": len(self.execution_history),
            "successful_queries": sum(1 for e in self.execution_history if e.success),
            "average_confidence": round(
                sum(e.confidence_score for e in self.execution_history) / 
                max(len(self.execution_history), 1), 3
            ),
            "average_execution_time_ms": round(
                sum(e.execution_time_ms for e in self.execution_history) / 
                max(len(self.execution_history), 1), 2
            ),
            "ml_model_stats": self.ml_manager.intent_agent._assess_urgency.__self__.__dict__ if hasattr(self.ml_manager, 'intent_agent') else {},
            "retrieval_stats": self.retrieval_agent.get_retrieval_statistics(),
            "safety_stats": self.safety_checker.get_safety_statistics(),
            "verification_stats": self.verification_agent.get_verification_statistics(),
        }
