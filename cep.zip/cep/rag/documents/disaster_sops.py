"""
Disaster Standard Operating Procedures (SOPs)
Comprehensive guidelines for various disaster scenarios
"""

DISASTER_SOPS = """
========================================
EARTHQUAKE RESPONSE PROCEDURES
========================================

IMMEDIATE ACTIONS (FIRST 60 SECONDS):
1. DROP to hands and knees immediately
2. COVER your head and neck under a sturdy table or against an interior wall
3. HOLD ON until shaking stops - do not run or use elevators

IF OUTDOORS:
- Move away from buildings, trees, and power lines
- Stay in open area until shaking stops

IF IN VEHICLE:
- Pull over safely and stay inside vehicle
- Avoid overpasses and bridges
- Resume driving slowly once shaking stops

AFTER SHAKING STOPS:
1. Check for injuries and provide first aid
2. Inspect building for damage (gas leaks, electrical damage)
3. Exit building if unsafe
4. Stay tuned to emergency broadcasts
5. Be prepared for aftershocks

EVACUATION ASSEMBLY POINTS:
- Register with emergency services
- Account for all family members
- Follow instructions of emergency responders

========================================
FLOOD RESPONSE PROCEDURES
========================================

PREPARATION PHASE:
1. Know your area's flood risk and evacuation routes
2. Prepare emergency kit: water, food, medications, documents
3. Have family communication plan established
4. Store important documents in waterproof containers

WHEN FLOOD WARNING IS ISSUED:
1. Monitor local emergency broadcasts continuously
2. Be ready to evacuate at short notice
3. Move to higher ground with emergency supplies
4. Avoid driving/walking through flooded areas

DURING EVACUATION:
1. Use designated evacuation routes only
2. Take essential documents and medications
3. Lock your home if time permits
4. Turn off utilities at mains if instructed
5. Follow traffic control personnel

NEVER:
- Drive through flooded roads - "Turn Around, Don't Drown"
- Wade through moving water
- Believe water depth is safe based on appearance

AFTER FLOOD:
1. Return home only when authorities declare it safe
2. Document damage with photographs for insurance
3. Check for contamination before using water
4. Beware of downed power lines
5. Dispose of contaminated food/medication safely

========================================
WILDFIRE EVACUATION PROCEDURES
========================================

PREPARATION:
1. Maintain defensible space around home (30+ feet)
2. Clear gutters and roof of leaves/debris
3. Know evacuation routes - have multiple options
4. Pack "Go Bag" with essentials
5. Maintain vehicle with at least 1/2 tank fuel

WHEN EVACUATION ORDER IS ISSUED:
1. Leave immediately - do not delay or wait
2. Wear long sleeves, long pants, sturdy shoes
3. Take pre-packed Go Bag and important documents
4. Take medications and medical equipment
5. Notify family you are evacuating

DRIVING TO SAFETY:
1. Keep headlights on and windows/vents closed
2. Drive slowly and watch for other evacuees
3. Avoid roads blocked by smoke or fire
4. Do not stop or turn back for belongings
5. Head toward designated evacuation areas

IF TRAPPED:
1. Close all doors and windows
2. Turn on lights for visibility in smoke
3. Stay calm and call 911 with your location
4. Await rescue - do not attempt escape on foot
5. If outside, avoid vegetation and move to cleared area

AFTER EVACUATION:
1. Monitor news for all-clear signal
2. Return home only when officially authorized
3. Document property damage for insurance
4. Check for hot spots and live embers
5. Boil water before consumption

========================================
HURRICANE/TROPICAL CYCLONE PROCEDURES
========================================

PREPARATION (BEFORE SEASON):
1. Know your hurricane zone and evacuation areas
2. Prepare emergency kit for 1 week
3. Secure outdoor furniture and items
4. Trim trees and clear drainage areas
5. Know how to shut off utilities

WHEN WATCH IS ISSUED:
1. Monitor National Weather Service updates closely
2. Ensure vehicle is fueled and ready
3. Bring in outdoor items that could become projectiles
4. Stock up on supplies and medications
5. Prepare property

WHEN WARNING IS ISSUED:
1. Evacuate immediately if ordered
2. Secure home and leave immediately
3. Use designated evacuation routes
4. Go to shelter or pre-arranged safe location
5. Do not stay in mobile homes or high-rise buildings

DURING HURRICANE (IF SHELTERING IN PLACE):
1. Stay in interior room on lowest floor
2. Away from windows and glass doors
3. Bring pets and essential supplies inside
4. Monitor emergency broadcasts
5. Do not go outside despite calm (eye of hurricane)

AFTER HURRICANE:
1. Wait for official all-clear before leaving shelter
2. Watch for hazards: downed lines, contaminated water, gas leaks
3. Document all damage with photographs
4. Use generators outside and away from windows
5. Boil water or use bottled water until cleared
6. Avoid floodwaters and flooded roads

========================================
CHEMICAL SPILL/HAZMAT PROCEDURES
========================================

IMMEDIATE RESPONSE:
1. Check wind direction and move upwind/uphill
2. Do not approach the spill area
3. Leave the area immediately
4. Call emergency services (911) with location and substance info

SHELTER IN PLACE (IF EVACUATION NOT POSSIBLE):
1. Close all doors and windows
2. Shut off air conditioning and ventilation
3. Seal doors with wet towels and tape
4. Go to highest level of building
5. Avoid basements

DO NOT:
- Touch or handle spilled material
- Assume gas/chemical is harmless
- Use elevators
- Attempt rescue without proper equipment

AFTER ALL-CLEAR:
1. Return home only when authorized
2. Follow instructions for decontamination
3. Seek medical attention for exposure symptoms
4. Report symptoms to authorities
5. Keep documentation of exposure

========================================
PANDEMIC RESPONSE PROCEDURES
========================================

PREVENTION MEASURES:
1. Maintain respiratory hygiene
2. Regular hand hygiene (20+ seconds)
3. Avoid gatherings in early outbreak phase
4. Wear appropriate PPE when required
5. Maintain physical distance (6+ feet) from ill persons

WHEN SUSPECTED INFECTION:
1. Isolate immediately from others
2. Contact healthcare provider or hotline
3. Get tested if directed
4. Keep detailed contact records
5. Quarantine per health authority guidance

DURING COMMUNITY TRANSMISSION:
1. Limit non-essential trips outside home
2. Wear mask in public settings
3. Maintain hygiene protocols
4. Stay informed via official sources only
5. Practice stress management

FOR VULNERABLE POPULATIONS:
1. Elderly and immunocompromised: stay home
2. Access supplies via delivery or assistance
3. Monitor health symptoms closely
4. Have 30-day medication supply
5. Maintain regular medical consultations

VACCINATION AND MEDICAL:
1. Follow vaccination guidance from health authorities
2. Keep vaccination records updated
3. Seek immediate medical attention for severe symptoms
4. Report adverse events to appropriate authorities
5. Access mental health support if needed

========================================
SEVERE STORM/TORNADO PROCEDURES
========================================

PREPARATION:
1. Know weather safe room in your building
2. Know nearest shelter if in mobile home
3. Have emergency supplies ready
4. Know how to receive weather warnings
5. Practice tornado drill with family

WHEN TORNADO WARNING IS ISSUED:
1. Go to safe room immediately (interior room, lowest level)
2. Bring phone, medication, first aid kit
3. Get under sturdy desk or bench if possible
4. Cover head and neck with arms
5. Do not open windows

SAFE ROOMS:
- Basement or interior room on lowest level
- Bathrooms in interior of building
- Small interior room with no windows
- Away from exterior walls and windows

IF CAUGHT OUTSIDE:
1. Do not try to outrun tornado in car if nearby
2. Abandon vehicle if tornado unavoidable
3. Lie flat in lowest area (ditch/depression)
4. Cover head and neck with hands
5. Do not hide under overpass (dangerous winds)

AFTER TORNADO:
1. Listen for all-clear from authorities
2. Check self and others for injuries
3. Exit building only if safe (check structural integrity)
4. Avoid fallen power lines
5. Document damage and injuries

========================================
GENERAL SAFETY PRINCIPLES
========================================

COMMUNICATION:
- Listen ONLY to official emergency broadcasts
- Use text messaging if voice calls are overloaded
- Register with emergency services
- Keep emergency contact information

SUPPLIES CHECKLIST:
- Water (1 gallon/person/day for 3+ days)
- Non-perishable food
- Medications and medical supplies
- Important documents
- Change of clothes and sturdy shoes
- First aid kit
- Flashlight and batteries
- Cash and cards

SPECIAL NEEDS:
- Keep medications in original containers with labels
- Maintain list of medical conditions and allergies
- Ensure mobility aids are accessible
- Have extra supplies for dependent pets

INFRASTRUCTURE:
- Know how to shut off gas, water, electricity
- Know location of fire extinguishers
- Know emergency numbers and shelters
- Know evacuation routes from all locations

========================================
"""


def get_disaster_sops() -> str:
    """Retrieve complete disaster SOPs database"""
    return DISASTER_SOPS


def get_sops_for_disaster(disaster_type: str) -> str:
    """Extract specific procedures for a disaster type"""
    disaster_type_upper = disaster_type.upper()
    
    disaster_mapping = {
        "EARTHQUAKE": "EARTHQUAKE RESPONSE PROCEDURES",
        "FLOOD": "FLOOD RESPONSE PROCEDURES",
        "WILDFIRE": "WILDFIRE EVACUATION PROCEDURES",
        "HURRICANE": "HURRICANE/TROPICAL CYCLONE PROCEDURES",
        "TORNADO": "SEVERE STORM/TORNADO PROCEDURES",
        "TSUNAMI": "EARTHQUAKE RESPONSE PROCEDURES",
        "CHEMICAL_SPILL": "CHEMICAL SPILL/HAZMAT PROCEDURES",
        "PANDEMIC": "PANDEMIC RESPONSE PROCEDURES",
    }
    
    section_header = disaster_mapping.get(disaster_type_upper)
    if not section_header:
        return DISASTER_SOPS
    
    lines = DISASTER_SOPS.split('\n')
    start_idx = None
    end_idx = None
    
    for i, line in enumerate(lines):
        if section_header in line:
            start_idx = i
        elif start_idx is not None and "========" in line and i > start_idx + 5:
            end_idx = i
            break
    
    if start_idx is not None:
        end_idx = end_idx or len(lines)
        return '\n'.join(lines[start_idx:end_idx])
    
    return DISASTER_SOPS
