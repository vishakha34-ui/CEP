"""
Vector Store and RAG (Retrieval-Augmented Generation) Module
Implements document ingestion, embedding, and semantic retrieval
"""

import hashlib
import numpy as np
from typing import List, Dict, Tuple
from dataclasses import dataclass
from datetime import datetime
import json


@dataclass
class Document:
    """Represents a chunk of documentation"""
    content: str
    doc_id: str
    source: str
    chunk_index: int


class SimpleEmbeddingEngine:
    """
    Simple embedding engine using TF-IDF-like approach.
    In production, would use sentence-transformers or similar.
    """
    
    def __init__(self):
        """Initialize embedding engine with vocabulary"""
        self.vocabulary = set()
        self.document_vectors = {}
        self.vocab_index = {}
    
    def create_vocabulary(self, documents: List[str]):
        """Build vocabulary from documents"""
        for doc in documents:
            words = self._tokenize(doc)
            self.vocabulary.update(words)
        
        self.vocab_index = {word: idx for idx, word in enumerate(sorted(self.vocabulary))}
    
    def embed(self, text: str) -> np.ndarray:
        """Create embedding vector for text"""
        words = self._tokenize(text)
        vector = np.zeros(len(self.vocabulary))
        
        for word in words:
            if word in self.vocab_index:
                idx = self.vocab_index[word]
                vector[idx] += 1
        
        # Normalize
        norm = np.linalg.norm(vector)
        if norm > 0:
            vector = vector / norm
        
        return vector
    
    def similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Compute cosine similarity between vectors"""
        return float(np.dot(vec1, vec2))
    
    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Simple tokenization"""
        return text.lower().split()


class VectorStore:
    """
    Vector Store: Manages document embeddings and retrieval.
    
    Implements:
    - Document ingestion and chunking
    - Embedding generation
    - Similarity-based retrieval
    - Metadata management
    """
    
    def __init__(self, chunk_size: int = 500, overlap: int = 50):
        """
        Initialize vector store.
        
        Args:
            chunk_size: Size of text chunks in characters
            overlap: Overlap between chunks for context preservation
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.documents: List[Document] = []
        self.embeddings: Dict[str, np.ndarray] = {}
        self.embedding_engine = SimpleEmbeddingEngine()
        self.metadata: Dict[str, Dict] = {}
    
    def ingest_documents(self, documents: Dict[str, str]):
        """
        Ingest multiple documents.
        
        Args:
            documents: Dict mapping source names to document content
        """
        all_text = []
        doc_chunks = {}
        
        # Chunk all documents
        for source, content in documents.items():
            chunks = self._chunk_text(content, source)
            doc_chunks[source] = chunks
            all_text.append(content)
        
        # Create vocabulary and embeddings
        self.embedding_engine.create_vocabulary(all_text)
        
        # Store chunks and create embeddings
        doc_id_counter = 0
        for source, chunks in doc_chunks.items():
            for chunk_idx, chunk_text in enumerate(chunks):
                doc_id = f"{source}_chunk_{chunk_idx}"
                doc = Document(
                    content=chunk_text,
                    doc_id=doc_id,
                    source=source,
                    chunk_index=chunk_idx
                )
                self.documents.append(doc)
                
                # Create embedding
                embedding = self.embedding_engine.embed(chunk_text)
                self.embeddings[doc_id] = embedding
                
                # Store metadata
                self.metadata[doc_id] = {
                    "source": source,
                    "chunk_index": chunk_idx,
                    "length": len(chunk_text),
                    "ingested_at": datetime.now().isoformat()
                }
                
                doc_id_counter += 1
    
    def _chunk_text(self, text: str, source: str) -> List[str]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Text to chunk
            source: Source identifier
            
        Returns:
            List of text chunks with overlap
        """
        chunks = []
        start = 0
        
        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            chunk = text[start:end]
            chunks.append(chunk)
            
            # Move start position with overlap
            start = end - self.overlap if end < len(text) else len(text)
        
        return chunks if chunks else [text]
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Retrieve most relevant documents for a query.
        
        Args:
            query: Search query
            top_k: Number of results to return
            
        Returns:
            List of relevant documents with scores
        """
        if not self.documents:
            return []
        
        # Embed query
        query_embedding = self.embedding_engine.embed(query)
        
        # Score all documents
        scores = {}
        for doc_id, doc_embedding in self.embeddings.items():
            similarity = self.embedding_engine.similarity(query_embedding, doc_embedding)
            scores[doc_id] = similarity
        
        # Get top-k results
        top_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        
        results = []
        for doc_id, score in top_docs:
            doc = next((d for d in self.documents if d.doc_id == doc_id), None)
            if doc:
                results.append({
                    "doc_id": doc_id,
                    "content": doc.content,
                    "source": doc.source,
                    "score": round(float(score), 3),
                    "metadata": self.metadata.get(doc_id, {})
                })
        
        return results
    
    def get_stats(self) -> Dict:
        """Get statistics about stored documents"""
        return {
            "total_documents": len(self.documents),
            "total_chunks": len(self.embeddings),
            "chunk_size": self.chunk_size,
            "chunk_overlap": self.overlap,
            "sources": list(set(d.source for d in self.documents)),
            "vocabulary_size": len(self.embedding_engine.vocabulary)
        }


class RetrievalAugmentedGenerationEngine:
    """
    RAG Engine: Combines vector store retrieval with LLM-based generation.
    
    Workflow:
    1. Ingest documents into vector store
    2. On query: retrieve relevant documents
    3. Augment prompt with retrieved context
    4. Generate response using LLM with grounded context
    """
    
    def __init__(self):
        """Initialize RAG engine"""
        self.vector_store = VectorStore()
        self.retrieval_history = []
    
    def setup_knowledge_base(self, documents: Dict[str, str]):
        """
        Set up RAG knowledge base from documents.
        
        Args:
            documents: Dict mapping source names to content
        """
        self.vector_store.ingest_documents(documents)
    
    def augment_query(self, query: str, top_k: int = 5) -> Dict:
        """
        Augment query with relevant context from knowledge base.
        
        Args:
            query: User query
            top_k: Number of documents to retrieve
            
        Returns:
            Query with augmented context for LLM
        """
        # Retrieve relevant documents
        retrieved_docs = self.vector_store.retrieve(query, top_k=top_k)
        
        # Build augmented prompt
        context = ""
        if retrieved_docs:
            context = "RETRIEVED CONTEXT:\n"
            for i, doc in enumerate(retrieved_docs, 1):
                context += f"\n[Source {i}: {doc['source']}]\n"
                context += f"{doc['content'][:500]}...\n"
                context += f"(Relevance Score: {doc['score']})\n"
        
        # Track retrieval
        self.retrieval_history.append({
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "retrieved_documents": len(retrieved_docs),
            "top_score": retrieved_docs[0]["score"] if retrieved_docs else 0
        })
        
        return {
            "original_query": query,
            "augmented_context": context,
            "retrieved_documents": retrieved_docs,
            "retrieval_count": len(retrieved_docs),
            "has_relevant_context": len(retrieved_docs) > 0
        }
    
    def get_retrieval_stats(self) -> Dict:
        """Get statistics about RAG performance"""
        if not self.retrieval_history:
            return {"queries_processed": 0}
        
        scores = [r["top_score"] for r in self.retrieval_history]
        
        return {
            "queries_processed": len(self.retrieval_history),
            "avg_retrieval_score": round(np.mean(scores), 3),
            "max_retrieval_score": round(max(scores), 3),
            "min_retrieval_score": round(min(scores), 3),
            "knowledge_base_stats": self.vector_store.get_stats()
        }
