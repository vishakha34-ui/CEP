"""
Streamlit Dashboard for Disaster Management System
Interactive UI running on localhost:8501
"""

import streamlit as st
import requests
import json
from datetime import datetime
from typing import Dict, List
import time

# Page configuration
st.set_page_config(
    page_title="Disaster Management Advisory System",
    page_icon="🚨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .critical { color: #ff0000; font-weight: bold; }
    .high { color: #ff6600; font-weight: bold; }
    .moderate { color: #ffaa00; font-weight: bold; }
    .low { color: #00aa00; font-weight: bold; }
    .advisory-box { background-color: #f0f0f0; padding: 20px; border-radius: 10px; }
    .metric-box { background-color: #e8f4f8; padding: 15px; border-radius: 8px; margin: 10px 0; }
</style>
""", unsafe_allow_html=True)

# API Configuration
API_BASE_URL = "http://localhost:8000/api/v1"
BACKEND_HEALTH_URL = "http://localhost:8000/health"

# Session state initialization
if "query_history" not in st.session_state:
    st.session_state.query_history = []

if "api_available" not in st.session_state:
    st.session_state.api_available = False


def check_api_availability():
    """Check if backend API is available"""
    try:
        response = requests.get(BACKEND_HEALTH_URL, timeout=2)
        return response.status_code == 200
    except:
        return False


def submit_query(query_text: str) -> Dict:
    """Submit disaster query to backend API"""
    try:
        response = requests.post(
            f"{API_BASE_URL}/analyze",
            json={"query_text": query_text},
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {
                "success": False,
                "error": f"API error: {response.status_code}",
                "final_advisory": "Error contacting backend API"
            }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "error": "Cannot connect to backend API",
            "final_advisory": "Backend API is not running on localhost:8000"
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "final_advisory": "Error processing query"
        }


def format_severity(severity: str) -> str:
    """Format severity with color coding"""
    severity_map = {
        "CRITICAL": "critical",
        "HIGH": "high",
        "MODERATE": "moderate",
        "LOW": "low",
        "MINIMAL": "low"
    }
    css_class = severity_map.get(severity, "moderate")
    return f"<span class='{css_class}'>{severity}</span>"


def display_guidance(guidance: Dict):
    """Display guidance in organized sections"""
    
    if not guidance or not guidance.get("immediate_actions"):
        st.warning("No guidance available")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🚨 Immediate Actions (Priority Order)")
        for i, action in enumerate(guidance.get("immediate_actions", [])[:5], 1):
            st.markdown(f"**{i}.** {action}")
    
    with col2:
        st.subheader("🚪 Evacuation Procedures")
        for i, proc in enumerate(guidance.get("evacuation_procedures", [])[:5], 1):
            st.markdown(f"**{i}.** {proc}")
    
    col3, col4 = st.columns(2)
    
    with col3:
        st.subheader("🛡️ Safety Instructions")
        for i, safety in enumerate(guidance.get("safety_instructions", [])[:5], 1):
            st.markdown(f"**{i}.** {safety}")
    
    with col4:
        st.subheader("📍 Resources & Locations")
        for resource in guidance.get("resources", [])[:5]:
            st.markdown(f"• {resource}")
    
    st.subheader("📞 Emergency Contacts")
    col_contacts = st.columns(min(3, len(guidance.get("emergency_contacts", []))))
    for idx, contact in enumerate(guidance.get("emergency_contacts", [])[:3]):
        with col_contacts[idx]:
            st.markdown(f"**{contact}**")


def display_risk_assessment(risk: Dict):
    """Display risk assessment in metrics"""
    
    if not risk:
        return
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Severity Score",
            f"{risk.get('severity_score', 0)}/100",
            delta=None
        )
    
    with col2:
        severity_cat = risk.get("severity_category", "UNKNOWN")
        st.metric(
            "Severity Category",
            severity_cat
        )
    
    with col3:
        affected_count = len(risk.get("affected_populations", []))
        st.metric(
            "Affected Populations",
            affected_count
        )
    
    with col4:
        infra_count = len(risk.get("infrastructure_at_risk", []))
        st.metric(
            "Infrastructure at Risk",
            infra_count
        )
    
    # Display populations
    if risk.get("affected_populations"):
        st.write("**Vulnerable Populations:** " + ", ".join(risk["affected_populations"]))
    
    # Display infrastructure
    if risk.get("infrastructure_at_risk"):
        st.write("**Infrastructure at Risk:** " + ", ".join(risk["infrastructure_at_risk"]))


def display_classification(classification: Dict):
    """Display disaster classification"""
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        disaster = classification.get("disaster_type", "UNKNOWN").upper()
        st.metric("Disaster Type", disaster)
    
    with col2:
        confidence = int(classification.get("confidence", 0) * 100)
        st.metric("Classification Confidence", f"{confidence}%")
    
    with col3:
        urgency = classification.get("urgency_level", "UNKNOWN")
        st.metric("Urgency Level", urgency)


def display_verification_status(verification: Dict):
    """Display verification status"""
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status = "✅ VERIFIED" if verification.get("verified") else "⚠️ UNVERIFIED"
        st.metric("Verification Status", status)
    
    with col2:
        confidence = int(verification.get("confidence", 0) * 100)
        st.metric("Verification Confidence", f"{confidence}%")
    
    with col3:
        issues = len(verification.get("issues", []))
        if issues > 0:
            st.metric("Issues Found", issues, delta="-1" if issues <= 1 else None)
        else:
            st.metric("Issues Found", "None")


def display_safety_check(safety: Dict):
    """Display safety check results"""
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status = "✅ SAFE" if safety.get("is_safe") else "⚠️ UNSAFE"
        st.metric("Safety Status", status)
    
    with col2:
        risk = safety.get("risk_level", "UNKNOWN")
        st.metric("Safety Risk Level", risk)
    
    with col3:
        score = int(safety.get("score", 0) * 100)
        st.metric("Safety Score", f"{score}%")


# ============================================================================
# MAIN DASHBOARD
# ============================================================================

st.title("🚨 Disaster Management & Public Safety Advisory System")

# Header info
st.markdown("""
This AI-powered system provides real-time disaster analysis, risk assessment, and safety guidance using:
- **Multi-Agent Architecture** for coordinated decision-making
- **Machine Learning** for intent classification and severity prediction
- **Retrieval-Augmented Generation (RAG)** for grounded information retrieval
- **Verification Agents** to ensure safety and accuracy
""")

# Sidebar
with st.sidebar:
    st.header("⚙️ System Status")
    
    # Check API availability
    api_available = check_api_availability()
    st.session_state.api_available = api_available
    
    if api_available:
        st.success("✅ Backend API: Connected")
        st.markdown("http://localhost:8000")
    else:
        st.error("❌ Backend API: Disconnected")
        st.warning("""
        Please ensure the backend API is running:
        ```bash
        python backend/main.py
        ```
        or
        ```bash
        uvicorn backend.main:app --host 0.0.0.0 --port 8000
        ```
        """)
    
    st.divider()
    
    st.subheader("📊 Quick Stats")
    
    # Try to get system stats
    try:
        response = requests.get(f"{API_BASE_URL}/system/status", timeout=2)
        if response.status_code == 200:
            stats = response.json().get("system_metrics", {})
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Queries Processed", stats.get("queries_processed", 0))
            with col2:
                st.metric("Success Rate", f"{int(stats.get('successful_queries', 0) / max(stats.get('queries_processed', 1), 1) * 100)}%")
    except:
        pass
    
    st.divider()
    
    st.subheader("📚 Sample Queries")
    samples = {
        "Earthquake": "There's an earthquake happening right now with strong shaking!",
        "Flood": "Severe flooding reported in low-lying areas near the river",
        "Wildfire": "Major wildfire spreading rapidly toward residential areas",
        "Hurricane": "Hurricane warning - strong winds and storm surge expected",
        "Chemical Spill": "Chemical hazard material has been reported as spilled",
    }
    
    selected_sample = st.selectbox("Choose a sample:", list(samples.keys()))
    if st.button("Load Sample Query", key="load_sample"):
        st.session_state.query_text = samples[selected_sample]
        st.rerun()

# Main content
if not st.session_state.api_available:
    st.error("⚠️ **System Unavailable**")
    st.markdown("""
    The backend API is not running. To start the system:
    
    1. **Terminal 1** (Backend API):
    ```bash
    cd c:\\Users\\User\\Desktop\\cep
    python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
    ```
    
    2. **Terminal 2** (Dashboard):
    ```bash
    cd c:\\Users\\User\\Desktop\\cep
    streamlit run dashboard/app.py --server.port 8501
    ```
    """)
else:
    # Query input
    st.subheader("🔍 Disaster Query Input")
    
    query_input = st.text_area(
        "Describe the disaster situation:",
        placeholder="E.g., 'There is a severe earthquake happening now with strong shaking in my area'",
        height=100,
        key="query_input"
    )
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        submit_button = st.button(
            "🚀 Analyze Disaster",
            type="primary",
            use_container_width=True,
            disabled=not query_input
        )
    
    with col2:
        clear_button = st.button("🗑️ Clear", use_container_width=True)
    
    with col3:
        history_toggle = st.checkbox("📋 History")
    
    if clear_button:
        st.session_state.query_input = ""
        st.rerun()
    
    # Process query
    if submit_button and query_input:
        st.divider()
        
        with st.spinner("🔄 Analyzing disaster scenario..."):
            result = submit_query(query_input)
        
        if result.get("success"):
            # Add to history
            st.session_state.query_history.insert(0, {
                "timestamp": datetime.now(),
                "query": query_input,
                "result": result
            })
            
            # Create tabs for different sections
            tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
                "📋 Advisory",
                "🎯 Classification",
                "📊 Risk Assessment",
                "✅ Verification",
                "🛡️ Safety Check",
                "⚙️ Details"
            ])
            
            # Tab 1: Final Advisory
            with tab1:
                st.subheader("Final Disaster Advisory")
                advisory_box = st.container()
                with advisory_box:
                    st.markdown("""
                    <div class="advisory-box">
                    """, unsafe_allow_html=True)
                    st.write(result.get("final_advisory", "No advisory available"))
                    st.markdown("</div>", unsafe_allow_html=True)
                
                # Confidence score
                confidence = int(result.get("confidence_score", 0) * 100)
                st.progress(confidence / 100, text=f"Overall Confidence: {confidence}%")
            
            # Tab 2: Classification
            with tab2:
                st.subheader("Disaster Classification Analysis")
                classification = result.get("disaster_classification", {})
                display_classification(classification)
            
            # Tab 3: Risk Assessment
            with tab3:
                st.subheader("Risk Assessment Details")
                risk = result.get("risk_assessment", {})
                display_risk_assessment(risk)
            
            # Tab 4: Guidance
            with tab4:
                st.subheader("Actionable Guidance")
                guidance = result.get("guidance", {})
                display_guidance(guidance)
            
            # Tab 5: Verification
            with tab5:
                col1, col2 = st.columns(2)
                with col1:
                    st.subheader("Verification Status")
                    verification = result.get("verification", {})
                    display_verification_status(verification)
                
                with col2:
                    st.subheader("Safety Assessment")
                    safety = result.get("safety_check", {})
                    display_safety_check(safety)
            
            # Tab 6: Execution Details
            with tab6:
                st.subheader("System Execution Details")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Execution Time", f"{result.get('execution_time_ms', 0):.0f}ms")
                    st.metric("Query ID", result.get("query_id", "N/A")[:8] + "...")
                
                with col2:
                    st.metric("Retrieved Documents", len(result.get("retrieved_context", {}).get("document_count", 0)))
                    st.metric("Safety Risk Level", result.get("safety_check", {}).get("risk_level", "UNKNOWN"))
                
                if result.get("warnings"):
                    st.warning("⚠️ **Warnings:**")
                    for warning in result["warnings"]:
                        st.markdown(f"• {warning}")
                
                # Execution logs
                if st.checkbox("Show Execution Logs"):
                    st.subheader("Agent Execution Logs")
                    logs = result.get("execution_logs", [])
                    for log in logs:
                        with st.expander(f"{log['agent']} - {log['state']} ({log['duration_ms']:.0f}ms)"):
                            st.json(log)
        
        else:
            st.error(f"❌ **Query Failed**: {result.get('error', 'Unknown error')}")
            st.info(result.get("final_advisory", "Contact emergency services: 911"))
    
    # Query History
    if history_toggle and st.session_state.query_history:
        st.divider()
        st.subheader("📋 Query History")
        
        for i, item in enumerate(st.session_state.query_history[:5]):
            with st.expander(f"{item['timestamp'].strftime('%H:%M:%S')} - {item['query'][:50]}..."):
                st.write("**Query:**", item['query'])
                result = item['result']
                
                if result.get("success"):
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric(
                            "Type",
                            result.get("disaster_classification", {}).get("disaster_type", "N/A")
                        )
                    with col2:
                        st.metric(
                            "Severity",
                            result.get("risk_assessment", {}).get("severity_category", "N/A")
                        )
                    with col3:
                        st.metric(
                            "Confidence",
                            f"{int(result.get('confidence_score', 0) * 100)}%"
                        )
                else:
                    st.error(f"Failed: {result.get('error', 'Unknown error')}")

# Footer
st.divider()
st.markdown("""
---
**Disaster Management & Public Safety Advisory System** | v1.0.0

**⚠️ Disclaimer:** This system is designed to provide advisory information only. For life-threatening emergencies, 
always contact emergency services (911) immediately. Follow official guidance from local emergency management authorities.

**System Features:**
- Multi-Agent AI Architecture with coordinated decision-making
- Machine Learning-based disaster classification and risk assessment
- RAG-enhanced information retrieval for accurate SOP guidance
- Verification and safety checking to prevent harmful advice
- Real-time processing with comprehensive execution logging
""")
